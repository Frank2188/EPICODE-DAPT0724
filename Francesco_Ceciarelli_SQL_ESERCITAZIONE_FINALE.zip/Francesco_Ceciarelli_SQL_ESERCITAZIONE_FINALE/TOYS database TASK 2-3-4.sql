create database TOYSdatabase;

use TOYSdatabase;

create table Category 
(
CategoryID int auto_increment primary key
,CategoryName varchar (25)
,Description varchar (100)
);


create table product
(ProductID int auto_increment primary key
, ProductName varchar (50)
, Description varchar (100)
, CategoryID int
, ListPrice decimal (7,2)
, DealerPrice decimal (7,2)
, LaunchDate date );


create table sales
( SaleID int auto_increment primary key
,SaleDate DAtetime
,ProductID int
,SalesPointID int
,CustomerID int
);


create table customer
(CustomerID int auto_increment primary key
,FirstNAme varchar (25)
,Lastname varchar (25)
,Addressline varchar ( 100)
,City varchar (20)
,Postalcode char(10)
,Phone varchar (25)
,Email varchar (50)
);


create table Sales_Point
(SalesPointID int auto_increment primary key
, SalesPointName Varchar (50)
, StateID int
, Addressline varchar ( 100)
,City varchar (20)
,Postalcode char(10)
);


create table State
(StateID int auto_increment primary key
,StateName Varchar (20)
,RegionID int
);


Create Table Region 
(RegionID int auto_increment primary key
,RegionName varchar  (25)
);


create table Inventory
(InventoryID int auto_increment primary key
,ProductID int
, StockQuantity int
,LastUpdate datetime
,RegionID int
);



alter table product
add constraint fk_product_category foreign key (CategoryID)
references Category(CategoryID);


alter table sales
add constraint fk_sales_product foreign key (ProductID)
references Product(ProductID);

alter table sales
add constraint fk_sales_customer foreign key (CustomerID)
references Customer(CustomerID);

alter table sales
add constraint fk_sales_sales_Point foreign key (SalesPointID)
references Sales_Point(SalesPointID);

alter table Sales_Point
add constraint fk_sales_Point_State foreign key (StateID)
references State(StateID);

alter table state
add constraint fk_state_region foreign key (RegionID)
references Region(RegionID);


alter table inventory
add constraint fk_inventory_region FOREIGN KEY (RegionID) REFERENCES region(RegionID);

alter table inventory
add constraint fk_inventory_product foreign key (ProductID)
references Product(ProductID);



INSERT INTO category (CategoryID, Categoryname, Description) 
VALUES 
(1, 'Educational Toys', 'Toys that help with learning and skill development'),
(2, 'Dolls and Stuffed Animals', 'Dolls and stuffed animals for role-playing and imagination'),
(3, 'Building Toys', 'Blocks and kits for creative building'),
(4, 'Outdoor Toys', 'Toys for outdoor fun'),
(5, 'Board Games', 'Games for fun with friends and family'),
(6, 'Cars and Vehicles', 'Toy cars and transportation vehicles'),
(7, 'Tracks and Train Sets', 'Tracks for toy cars and moving train sets'),
(8, 'Musical Toys', 'Toy musical instruments to stimulate creativity'),
(9, 'Plush Toys', 'Soft and cuddly plush toys in various shapes and sizes'),
(10, 'Tabletop Games', 'Strategy and skill games for adults and children'),
(11, 'Toys for Babies', 'Safe and soft toys for infants'),
(12, 'Wooden Toys', 'Traditional wooden toys for all ages'),
(13, 'Interactive Toys', 'Toys that respond to touch and encourage interaction'),
(14, 'DIY Toys', 'Creative kits to make handmade toys and objects'),
(15, 'Pool Toys', 'Floating toys for fun in the water'),
(16, 'Skill Games', 'Games that stimulate coordination and motor skills'),
(17, 'Augmented Reality Toys', 'Toys combining physical play with augmented reality'),
(18, 'Collectible Toys', 'Exclusive and collectible toys for enthusiasts'),
(19, 'Superhero Toys', 'Toys inspired by superheroes and their adventures'),
(20, 'Puzzle Games', 'Intelligence games that stimulate logical reasoning');


INSERT INTO product (ProductID, ProductName, Description, CategoryID, ListPrice, DealerPrice, LaunchDate)
VALUES
(1, 'Smart Learning Robot', 'A robot that teaches basic programming skills to kids', 1, 29.99, 20.99, '2023-06-15'),
(2, 'Interactive Dollhouse', 'A fully furnished dollhouse with interactive features', 2, 49.99, 35.00, '2024-01-10'),
(3, 'Wooden Blocks Set', 'Set of colorful wooden blocks for building and creating', 3, 19.99, 12.50, '2023-09-25'),
(4, 'Outdoor Kite', 'Brightly colored kite for outdoor fun in the wind', 4, 15.99, 10.50, '2023-11-05'),
(5, 'Classic Monopoly', 'A traditional board game for family fun', 5, 24.99, 18.00, '2022-12-01'),
(6, 'Mini Sports Car', 'A small toy car for racing and playing', 6, 9.99, 6.50, '2024-03-22'),
(7, 'Train Track Expansion', 'Additional pieces to expand your train set collection', 7, 14.99, 10.00, '2023-07-17'),
(8, 'Electric Keyboard Toy', 'A toy piano that plays various melodies and sounds', 8, 35.99, 24.00, '2024-02-08'),
(9, 'Cuddly Plush Bear', 'A soft and plush teddy bear for cuddling', 9, 19.99, 14.50, '2024-01-12'),
(10, 'Risk Board Game', 'Strategy game that challenges critical thinking', 10, 34.99, 25.00, '2022-12-15'),
(11, 'Baby Soft Rattle', 'A soft, colorful rattle for babies', 11, 8.99, 6.00, '2023-08-19'),
(12, 'Wooden Train Set', 'Traditional wooden train set with tracks and accessories', 12, 29.99, 20.00, '2023-11-11'),
(13, 'Interactive Talking Toy', 'A toy that responds to touch and sound', 13, 39.99, 28.00, '2023-06-30'),
(14, 'DIY Craft Kit', 'Make your own toys with this creative kit', 14, 22.99, 16.00, '2023-09-10'),
(15, 'Inflatable Pool Toy', 'A fun inflatable toy for the pool', 15, 18.99, 12.00, '2024-07-20'),
(16, 'Hand-Eye Coordination Game', 'Game designed to improve coordination and reflexes', 16, 12.99, 9.00, '2023-05-03'),
(17, 'Augmented Reality Dinosaur', 'A toy dinosaur with augmented reality features', 17, 49.99, 35.00, '2023-12-15'),
(18, 'Limited Edition Action Figure', 'A collectible superhero action figure', 18, 99.99, 75.00, '2023-08-28'),
(19, 'Superhero Playset', 'A toy playset with superhero figures and accessories', 19, 27.99, 20.00, '2024-01-05'),
(20, '3D Puzzle Game', 'A challenging 3D puzzle for critical thinkers', 20, 14.99, 10.50, '2024-04-01'),
(21, 'AI Learning Assistant', 'Smart educational assistant for children', 1, 59.99, 45.00, '2023-11-03'),
(22, 'Fashion Doll Set', 'Doll with various outfits and accessories', 2, 21.99, 15.00, '2024-05-15'),
(23, 'Creative Builder Set', 'A set of building pieces for constructing vehicles and buildings', 3, 27.99, 18.50, '2023-08-05'),
(24, 'Outdoor Soccer Ball', 'Durable soccer ball for outdoor play', 4, 12.99, 8.00, '2023-06-10'),
(25, 'Chess Set', 'Classic chess game for strategy lovers', 5, 22.99, 16.50, '2023-12-03'),
(26, 'Vintage Car Model', 'A model car for collectors and enthusiasts', 6, 35.99, 25.00, '2024-03-30'),
(27, 'Interactive Train Set', 'Train set with moving parts and sound effects', 7, 49.99, 38.00, '2023-10-20'),
(28, 'Toy Guitar', 'A plastic guitar for kids to learn music', 8, 17.99, 12.00, '2023-07-15'),
(29, 'Plush Bunny', 'Soft bunny rabbit plush toy', 9, 14.99, 9.50, '2024-02-10'),
(30, 'Settlers of Catan', 'Classic strategy game for family fun', 10, 44.99, 30.00, '2023-05-23'),
(31, 'Baby Musical Rattle', 'A soft rattle with music for babies', 11, 13.99, 9.00, '2024-01-18'),
(32, 'Wooden Puzzle Set', 'Set of wooden puzzles for young children', 12, 18.99, 12.50, '2023-08-22'),
(33, 'Talking Teddy Bear', 'Plush bear that talks and responds to touch', 13, 42.99, 30.00, '2023-11-30'),
(34, 'DIY Wooden Car Kit', 'Kit to make your own wooden toy car', 14, 16.99, 12.00, '2023-06-05'),
(35, 'Beach Ball', 'Colorful beach ball for poolside fun', 15, 9.99, 6.50, '2023-07-03'),
(36, 'Juggling Game', 'Game for improving hand-eye coordination', 16, 11.99, 7.00, '2024-02-18'),
(37, 'Augmented Reality Robot', 'Robot toy with AR interactive play', 17, 54.99, 40.00, '2023-10-05'),
(38, 'Superhero Doll Set', 'Set of superhero dolls with accessories', 19, 28.99, 22.00, '2024-01-14'),
(39, '3D Maze Puzzle', 'Puzzle that challenges spatial thinking', 20, 13.99, 9.00, '2024-03-28'),
(40, 'Educational Puzzle Game', 'Puzzle game that helps with learning shapes and colors', 1, 17.99, 11.50, '2024-01-25'),
(41, 'Interactive Fashion Doll', 'Doll with interactive features and clothing', 2, 29.99, 22.00, '2023-09-01'),
(42, 'Rocket Building Set', 'Building set to create your own rocket ship', 3, 24.99, 18.00, '2023-12-11'),
(43, 'Frisbee', 'Flying disc for outdoor play', 4, 7.99, 5.00, '2023-07-15'),
(44, 'Clue Game', 'Classic mystery-solving board game', 5, 19.99, 14.50, '2023-11-10'),
(45, 'Toy Motorcycle', 'Motorcycle toy for racing fun', 6, 21.99, 16.00, '2024-01-05'),
(46, 'Wooden Train Car', 'Additional train cars for your wooden train set', 7, 12.99, 9.00, '2023-09-22'),
(47, 'Piano Toy', 'Mini piano for young children to learn music', 8, 22.99, 16.50, '2024-01-02'),
(48, 'Stuffed Elephant', 'Plush elephant for cuddling', 9, 17.99, 12.00, '2024-02-25'),
(49, 'Scrabble', 'Classic word game for adults and children', 10, 19.99, 14.00, '2023-12-18'),
(50, 'Baby Teething Toy', 'Soft and safe teething toy for babies', 11, 8.99, 5.50, '2023-06-25'),
(51, 'Wooden Puzzle Cube', '3D wooden puzzle for children', 12, 15.99, 11.00, '2024-02-07'),
(52, 'Toy Robot', 'Interactive robot toy with sounds and movements', 13, 45.99, 33.00, '2023-09-10'),
(53, 'Craft Kit for Kids', 'Creative kit to make handmade toys', 14, 19.99, 14.00, '2024-03-01'),
(54, 'Inflatable Shark Toy', 'Shark-shaped inflatable toy for pool fun', 15, 27.99, 19.50, '2023-12-05'),
(55, 'Balance Game', 'Game that improves coordination and balance', 16, 13.99, 9.00, '2023-11-25'),
(56, 'Virtual Reality Dinosaur Toy', 'Toy dinosaur with VR features for interactive play', 17, 59.99, 45.00, '2024-01-15'),
(57, 'Superhero Playmat', 'Large mat for superhero-themed play', 19, 29.99, 20.00, '2024-02-22'),
(58, '3D Puzzle Cube', 'Challenging 3D puzzle cube for logic enthusiasts', 20, 11.99, 8.00, '2023-10-30'),
(59, 'Learning Flashcards', 'Flashcards for learning shapes, colors, and letters', 1, 14.99, 10.50, '2024-03-18'),
(60, 'Stuffed Animal Set', 'Collection of soft stuffed animals in different designs', 9, 24.99, 18.50, '2023-09-17'),
(61, 'Building and Construction Kit', 'Kit to build toy houses and vehicles', 3, 26.99, 20.00, '2023-12-02'),
(62, 'Outdoor Water Gun', 'Water gun for fun on hot summer days', 4, 15.99, 11.00, '2024-01-30'),
(63, 'Monopoly Deal', 'Card version of the classic Monopoly game', 5, 12.99, 8.50, '2023-06-18'),
(64, 'Toy Fire Truck', 'Fire truck toy with lights and sound', 6, 27.99, 19.50, '2024-03-05'),
(65, 'Toy Airplane', 'Small airplane toy for young pilots', 6, 18.99, 13.00, '2023-10-25'),
(66, 'Electric Car Track', 'Toy car track that features electric movement', 7, 45.99, 32.00, '2023-07-05'),
(67, 'Mini Drum Kit', 'Miniature drum set for young musicians', 8, 39.99, 28.00, '2024-04-12'),
(68, 'Plush Dog', 'A cuddly plush dog toy for children', 9, 16.99, 12.00, '2023-09-28'),
(69, 'Tigris and Euphrates', 'Board game of strategy and civilization building', 10, 42.99, 30.00, '2023-08-15'),
(70, 'Baby Play Mat', 'Safe play mat for babies with educational designs', 11, 25.99, 18.00, '2024-01-21'),
(71, 'Wooden Rocking Horse', 'Traditional wooden rocking horse', 12, 69.99, 50.00, '2023-12-13'),
(72, 'Interactive Teddy', 'Teddy bear with interactive voice features', 13, 38.99, 30.00, '2024-02-11'),
(73, 'Puzzle Blocks', 'Colorful blocks that form various puzzles', 12, 13.99, 9.00, '2024-01-16'),
(74, 'Craft Toy Set', 'Set for making your own toys and decorations', 14, 22.99, 16.00, '2023-08-10'),
(75, 'Inflatable Dolphin', 'Dolphin-shaped pool toy for water fun', 15, 24.99, 17.50, '2023-11-01'),
(76, 'Rock Climbing Game', 'Game that challenges physical and mental coordination', 16, 19.99, 14.00, '2024-01-23'),
(77, 'Interactive Robot Dog', 'Robot dog with sound and motion sensors', 13, 52.99, 40.00, '2024-02-03'),
(78, 'Superhero Action Set', 'Playset with superhero action figures and accessories', 19, 34.99, 25.00, '2024-01-30'),
(79, '3D Puzzle Ball', 'Challenging 3D puzzle for puzzle lovers', 20, 17.99, 12.00, '2024-03-25'),
(80, 'Learning Robot', 'Robot toy that teaches math and problem-solving', 1, 59.99, 45.00, '2023-12-20'),
(81, 'Doll Set with Furniture', 'Doll set with a variety of furniture pieces', 2, 39.99, 30.00, '2023-09-14'),
(82, 'Space Rocket Kit', 'Toy rocket that can be built and launched', 3, 32.99, 24.50, '2024-02-20'),
(83, 'Outdoor Jump Rope', 'Jump rope for outdoor physical fun', 4, 7.99, 5.00, '2024-04-05'),
(84, 'Guess Who? Board Game', 'Classic guessing game for family fun', 5, 14.99, 10.00, '2023-07-10'),
(85, 'Toy Bulldozer', 'Toy bulldozer with movable parts for construction play', 6, 27.99, 19.50, '2024-03-17'),
(86, 'Wooden Ship Model', 'Wooden model ship for construction and display', 12, 39.99, 28.00, '2023-10-10'),
(87, 'Robot Hand Puppets', 'Interactive robot-themed hand puppets for storytelling', 13, 22.99, 16.00, '2024-03-12'),
(88, 'Inflatable Pool Chair', 'Inflatable chair for relaxing in the pool', 15, 17.99, 12.50, '2023-08-30'),
(89, 'Tennis Board Game', 'Board game inspired by tennis matches', 5, 27.99, 20.00, '2024-03-10'),
(90, 'Mini Train Set', 'Miniature train set for young builders', 7, 24.99, 17.00, '2023-10-12'),
(91, 'Music Drum Set', 'Toy drum set with built-in songs and sounds', 8, 29.99, 22.00, '2023-11-22'),
(92, 'Stuffed Bear Family', 'Set of stuffed bears in different sizes', 9, 35.99, 25.00, '2024-01-18'),
(93, 'Tic-Tac-Toe Game', 'Classic Tic-Tac-Toe game for strategic thinking', 10, 6.99, 4.50, '2024-01-07'),
(94, 'Baby First Blocks', 'First set of soft blocks for young children', 11, 14.99, 10.00, '2023-12-08'),
(95, 'Wooden Toy Plane', 'Traditional wooden plane for kids', 12, 18.99, 13.00, '2024-01-22'),
(96, 'Superhero Trading Cards', 'Collection of superhero trading cards for collectors', 18, 14.99, 10.00, '2023-11-15'),
(97, 'Superhero Puzzle Game', 'Puzzle game with superhero images for young players', 20, 19.99, 15.00, '2024-04-03'),
(98, 'Interactive Toy Robot', 'Toy robot with touch and sound interaction', 13, 49.99, 36.00, '2023-08-12'),
(99, 'Limited Edition Action Doll', 'Exclusive action doll for collectors', 18, 79.99, 55.00, '2024-02-14'),
(100, 'Brain Teaser Game', 'Challenging game that tests logic and reasoning', 20, 22.99, 17.00, '2023-12-21');

INSERT INTO region (RegionID, RegionName)
VALUES
(1, 'North America'),
(2, 'South America'),
(3, 'North Europe'),
(4, 'South Europe'),
(5, 'Asia');

INSERT INTO state (StateID, StateName, RegionID)
VALUES

(1, 'United States', 1),
(2, 'Canada', 1),
(3, 'Mexico', 1),
(4, 'Cuba', 1),
(5, 'Guatemala', 1),
(6, 'Brazil', 2),
(7, 'Argentina', 2),
(8, 'Colombia', 2),
(9, 'Chile', 2),
(10, 'Peru', 2),
(11, 'United Kingdom', 3),
(12, 'Germany', 3),
(13, 'Norway', 3),
(14, 'Sweden', 3),
(15, 'Denmark', 3),
(16, 'Italy', 4),
(17, 'Spain', 4),
(18, 'France', 4),
(19, 'Portugal', 4),
(20, 'Greece', 4),
(21, 'China', 5),
(22, 'India', 5),
(23, 'Japan', 5),
(24, 'South Korea', 5),
(25, 'Thailand', 5);

INSERT INTO sales_point (SalesPointID, SalesPointName, StateID, AddressLine, City, PostalCode)
VALUES

(1, 'Toys R Us Downtown', 1, '123 Main St', 'New York', '10001'),
(2, 'Toys Kingdom Mall', 1, '456 Market St', 'Los Angeles', '90001'),
(3, 'Toys and Games', 1, '789 Broadway', 'Chicago', '60601'),
(4, 'Toys World', 1, '101 Toy Rd', 'Houston', '77001'),
(5, 'Toy Shop Central', 1, '202 Elm St', 'Miami', '33101'),
(6, 'Toys Wonderland', 2, '789 Maple Ave', 'Toronto', 'M5A 1A1'),
(7, 'The Toy Box', 2, '345 Queen St', 'Vancouver', 'V6B 1C5'),
(8, 'Toys for Kids', 2, '567 Yonge St', 'Ottawa', 'K1N 9B9'),
(9, 'Toy World', 2, '234 King St', 'Montreal', 'H2Y 1T1'),
(10, 'Toyland', 2, '890 Bay St', 'Calgary', 'T2P 1J9'),
(11, 'La Tienda de Toys', 3, '123 Avenida Reforma', 'Mexico City', '01000'),
(12, 'Toys R Us Mexico', 3, '456 Calle Morelos', 'Guadalajara', '44100'),
(13, 'Toys Land', 3, '789 Calle Juarez', 'Monterrey', '64000'),
(14, 'Toys Galore', 3, '101 Calle Madero', 'Cancun', '77500'),
(15, 'Toys for Fun', 3, '202 Plaza Hidalgo', 'Puebla', '72000'),
(16, 'Toys of Cuba', 4, '123 Calle Ocho', 'Havana', '10400'),
(17, 'El Mundo de los Toys', 4, '456 Avenida del Puerto', 'Varadero', '42200'),
(18, 'La Tienda de Toys', 4, '789 Calle 23', 'Santiago de Cuba', '90100'),
(19, 'Toys Paradise', 4, '101 Calle Martí', 'Holguín', '80300'),
(20, 'El Reino de los Toys', 4, '202 Calle 13', 'Santa Clara', '50100'),
(21, 'Toyland Guatemala', 5, '123 Avenida 1', 'Guatemala City', '01001'),
(22, 'La Casa de los Toys', 5, '456 Calle 5', 'Antigua Guatemala', '03001'),
(23, 'Toys World', 5, '789 Calle del Sol', 'Quetzaltenango', '09000'),
(24, 'La Tienda de Toys', 5, '101 Calle Real', 'Escuintla', '07000'),
(25, 'Toys Palace', 5, '202 Avenida Central', 'Chimaltenango', '04000'),
(26, 'Toy Paradise', 6, '123 Rua das Flores', 'São Paulo', '01000-000'),
(27, 'Toys and Games', 6, '456 Avenida Paulista', 'Rio de Janeiro', '20000-000'),
(28, 'Toy House', 6, '789 Rua XV', 'Salvador', '40000-000'),
(29, 'Toys Kingdom', 6, '101 Rua do Comércio', 'Belo Horizonte', '30000-000'),
(30, 'Toys Land', 6, '202 Rua dos Três Irmãos', 'Curitiba', '80000-000'),
(31, 'Toys House', 7, '123 Avenida Corrientes', 'Buenos Aires', '1041'),
(32, 'Toys World', 7, '456 Calle Florida', 'Cordoba', '5000'),
(33, 'Toys Galore', 7, '789 Calle San Martín', 'Rosario', '2000'),
(34, 'Toys and Fun', 7, '101 Calle 9 de Julio', 'Mendoza', '5500'),
(35, 'Toy Shop', 7, '202 Avenida Independencia', 'Tucumán', '4000'),
(36, 'Toys for Kids', 8, '123 Calle 23', 'Bogotá', '110010'),
(37, 'La Tienda de Toys', 8, '456 Carrera 10', 'Medellín', '050010'),
(38, 'Toys Galore', 8, '789 Calle 45', 'Cali', '760010'),
(39, 'Mundo de los Toys', 8, '101 Calle 4', 'Barranquilla', '080010'),
(40, 'Toys Paradise', 8, '202 Carrera 15', 'Cartagena', '130010'),
(41, 'Toys and More', 9, '123 Avenida Libertador', 'Santiago', '7500000'),
(42, 'Toys Planet', 9, '456 Calle de la Paz', 'Valparaíso', '2340000'),
(43, 'Toys Corner', 9, '789 Avenida O’Higgins', 'Concepción', '4030000'),
(44, 'Toys City', 9, '101 Kinsgway', 'La Serena', '1700000'),
(45, 'Toy Shop', 9, '202 Calle Victoria', 'Antofagasta', '1240000'),
(46, 'Toy Store Lima', 10, '123 Calle de la Cultura', 'Lima', '15000'),
(47, 'Toys Land', 10, '456 Avenida Pardo', 'Arequipa', '04000'),
(48, 'Toys House Peru', 10, '789 Calle Belgrano', 'Cusco', '08000'),
(49, 'La Tienda de Toys', 10, '101 Avenida Javier Prado', 'Trujillo', '13000'),
(50, 'Toys Peru', 10, '202 Calle Bolognesi', 'Chiclayo', '14000'),
(51, 'Toys Store London', 11, '123 Oxford Street', 'London', 'W1D 1LP'),
(52, 'Toys Kingdom', 11, '456 Regent Street', 'London', 'W1B 5BB'),
(53, 'Kids Toys Shop', 11, '789 King’s Road', 'Manchester', 'M1 1AA'),
(54, 'Toy Palace', 11, '101 Bond Street', 'Bristol', 'BS1 4AS'),
(55, 'Toys and Fun', 11, '202 High Street', 'Edinburgh', 'EH1 1BB'),
(56, 'Toys World', 12, '123 Berliner Str.', 'Berlin', '10115'),
(57, 'Toys & More', 12, '456 Ludwigstr.', 'Munich', '80331'),
(58, 'Toys House', 12, '789 Hauptstr.', 'Hamburg', '20095'),
(59, 'Toy Land', 12, '101 Marktplatz', 'Cologne', '50667'),
(60, 'Toys Fun', 12, '202 Kaiserstr.', 'Frankfurt', '60311'),
(61, 'Toys Shop Oslo', 13, '123 Karl Johans Gate', 'Oslo', '0154'),
(62, 'Toy City', 13, '456 Bislett', 'Bergen', '5003'),
(63, 'Toys & Games', 13, '789 Akersgata', 'Stavanger', '4005'),
(64, 'Toy Kingdom Oslo', 13, '101 Olav V’s Gate', 'Trondheim', '7013'),
(65, 'Little Toys', 13, '202 Torggata', 'Drammen', '3044'),
(66, 'Toys Heaven', 14, '123 Drottninggatan', 'Stockholm', '11151'),
(67, 'Toy House', 14, '456 Södra Förstadsgatan', 'Gothenburg', '41103'),
(68, 'Toy Planet', 14, '789 Västerlånggatan', 'Malmö', '21120'),
(69, 'Toys World', 14, '101 Kungsportsavenyn', 'Uppsala', '75321'),
(70, 'Toys City', 14, '202 Kungsgatan', 'Lund', '22210'),
(71, 'Toy Kingdom Copenhagen', 15, '123 Stroget', 'Copenhagen', '1000'),
(72, 'Toys World', 15, '456 H.C. Andersens Boulevard', 'Aarhus', '8000'),
(73, 'Toys House', 15, '789 Kongens Nytorv', 'Odense', '5000'),
(74, 'Toy Land', 15, '101 Vesterbrogade', 'Aalborg', '9000'),
(75, 'Toys R Us', 15, '202 Amagerbrogade', 'Esbjerg', '6700'),
(76, 'Toys World Rome', 16, '123 Via del Corso', 'Rome', '00100'),
(77, 'Toys Kingdom Milan', 16, '456 Corso Buenos Aires', 'Milan', '20100'),
(78, 'Toy Shop Florence', 16, '789 Via Tornabuoni', 'Florence', '50123'),
(79, 'Toys Galore Naples', 16, '101 Via Toledo', 'Naples', '80100'),
(80, 'Toys City Bologna', 16, '202 Via Rizzoli', 'Bologna', '40100'),
(81, 'Toys and Games Madrid', 17, '123 Gran Vía', 'Madrid', '28001'),
(82, 'Toys Store Barcelona', 17, '456 Passeig de Gràcia', 'Barcelona', '08007'),
(83, 'Toy House Valencia', 17, '789 Calle Colón', 'Valencia', '46001'),
(84, 'Toys Land Seville', 17, '101 Calle Tetuán', 'Seville', '41001'),
(85, 'Toys Paradise Bilbao', 17, '202 Gran Bilbao', 'Bilbao', '48001'),
(86, 'Toys Wonderland Paris', 18, '123 Rue de Rivoli', 'Paris', '75001'),
(87, 'Toy Shop Marseille', 18, '456 Avenue de la Canebière', 'Marseille', '13001'),
(88, 'Toys World Lyon', 18, '789 Rue de la République', 'Lyon', '69001'),
(89, 'Toys and Fun Toulouse', 18, '101 Rue Alsace-Lorraine', 'Toulouse', '31000'),
(90, 'Toys City Nice', 18, '202 Avenue Jean Médecin', 'Nice', '06000'),
(91, 'Toys House Lisbon', 19, '123 Avenida da Liberdade', 'Lisbon', '1250-001'),
(92, 'Toys World Porto', 19, '456 Rua de Santa Catarina', 'Porto', '4000-447'),
(93, 'Toy Shop Faro', 19, '789 Avenida da República', 'Faro', '8000-000'),
(94, 'Toys Paradise Coimbra', 19, '101 Rua Ferreira Borges', 'Coimbra', '3000-145'),
(95, 'Toy Kingdom Braga', 19, '202 Rua do Souto', 'Braga', '4700-004'),
(96, 'Toys and More Athens', 20, '123 Ermou Street', 'Athens', '10563'),
(97, 'Toys House Thessaloniki', 20, '456 Tsimiski Street', 'Thessaloniki', '54625'),
(98, 'Toy Store Patras', 20, '789 Korinthou Street', 'Patras', '26500'),
(99, 'Toys World Heraklion', 20, '101 Eleftherias Square', 'Heraklion', '71202'),
(100, 'Toys Kingdom Larissa', 20, '202 Megalou Alexandrou', 'Larissa', '41223'),
(101, 'Toys Paradise Beijing', 21, '123 Wangfujing Street', 'Beijing', '100001'),
(102, 'Toys World Shanghai', 21, '456 Nanjing Road', 'Shanghai', '200001'),
(103, 'Toy Shop Guangzhou', 21, '789 Beijing Road', 'Guangzhou', '510000'),
(104, 'Toys Kingdom Shenzhen', 21, '101 Luohu District', 'Shenzhen', '518000'),
(105, 'Toys Land Chengdu', 21, '202 Chunxi Road', 'Chengdu', '610000'),
(106, 'Toys World Mumbai', 22, '123 Colaba Causeway', 'Mumbai', '400005'),
(107, 'Toy Kingdom Delhi', 22, '456 Connaught Place', 'Delhi', '110001'),
(108, 'Toys Shop Bangalore', 22, '789 MG Road', 'Bangalore', '560001'),
(109, 'Toys Paradise Chennai', 22, '101 Anna Salai', 'Chennai', '600002'),
(110, 'Toys and Fun Kolkata', 22, '202 Park Street', 'Kolkata', '700016'),
(111, 'Toys Land Tokyo', 23, '123 Shibuya Crossing', 'Tokyo', '150-0002'),
(112, 'Toy House Osaka', 23, '456 Namba Station', 'Osaka', '5420076'),
(113, 'Toys Kingdom Kyoto', 23, '789 Kawaramachi Street', 'Kyoto', '6008001'),
(114, 'Toys World Yokohama', 23, '101 Minato Mirai', 'Yokohama', '220-0012'),
(115, 'Toy Store Sapporo', 23, '202 Odori Park', 'Sapporo', '060-0042'),
(116, 'Toys R Us Seoul', 24, '123 Gangnam District', 'Seoul', '06000'),
(117, 'Toys Shop Busan', 24, '456 Gwangalli Beach', 'Busan', '48300'),
(118, 'Toys Kingdom Incheon', 24, '789 Songdo District', 'Incheon', '22000'),
(119, 'Toy Land Daegu', 24, '101 Duryu Park', 'Daegu', '702-110'),
(120, 'Toys Paradise Gwangju', 24, '202 Chungjangno', 'Gwangju', '50000'),
(121, 'Toys Wonderland Bangkok', 25, '123 Sukhumvit Road', 'Bangkok', '10110'),
(122, 'Toy Shop Chiang Mai', 25, '456 Nimmanhaemin Road', 'Chiang Mai', '50200'),
(123, 'Toys Paradise Phuket', 25, '789 Patong Beach', 'Phuket', '83150'),
(124, 'Toys World Pattaya', 25, '101 Walking Street', 'Pattaya', '20150'),
(125, 'Toys and More Ayutthaya', 25, '202 Ayutthaya Road', 'Ayutthaya', '13000');


INSERT INTO customer (CustomerID, FirstName, LastName, AddressLine, City, PostalCode, Phone, Email)
VALUES
(1, 'John', 'Doe', '123 Main St', 'New York', '10001', '+1-212-555-1234', 'johndoe@example.com'),
(2, 'Jane', 'Smith', '456 Elm St', 'Los Angeles', '90001', '+1-323-555-5678', 'janesmith@example.com'),
(3, 'Carlos', 'Lopez', '789 Pine St', 'Chicago', '60601', '+1-312-555-2345', 'carloslopez@example.com'),
(4, 'Maria', 'Gonzalez', '321 Oak St', 'Houston', '77001', '+1-713-555-6789', 'mariagonzalez@example.com'),
(5, 'David', 'Johnson', '654 Maple St', 'Miami', '33101', '+1-305-555-9876', 'davidjohnson@example.com'),
(6, 'Emma', 'Martinez', '111 Birch St', 'Toronto', 'M5A 1A1', '+1-416-555-2468', 'emmamartinez@example.com'),
(7, 'Lucas', 'Brown', '222 Cedar St', 'Vancouver', 'V6B 1A1', '+1-604-555-1357', 'lucasbrown@example.com'),
(8, 'Sophia', 'Miller', '333 Redwood St', 'Ottawa', 'K1A 0B1', '+1-613-555-8888', 'sophiamiller@example.com'),
(9, 'Daniel', 'Wilson', '444 Fir St', 'Montreal', 'H2X 1Y2', '+1-514-555-7777', 'danielwilson@example.com'),
(10, 'Isabella', 'Taylor', '555 Pine St', 'Calgary', 'T2P 3C5', '+1-403-555-1234', 'isabellataylor@example.com'),
(11, 'Juan', 'Hernandez', '666 Oak St', 'Mexico City', '01000', '+52-55-5555-4321', 'juanhernandez@example.com'),
(12, 'Luis', 'Ramirez', '777 Cedar St', 'Guadalajara', '44100', '+52-33-5555-6789', 'luisramirez@example.com'),
(13, 'Ana', 'Perez', '888 Maple St', 'Monterrey', '64000', '+52-81-5555-1234', 'anaperez@example.com'),
(14, 'Carlos', 'Martínez', '999 Birch St', 'Cancun', '77500', '+52-998-555-5678', 'carlosmartinez@example.com'),
(15, 'Patricia', 'Lopez', '1000 Redwood St', 'Puebla', '72000', '+52-222-555-2345', 'patricialopez@example.com'),
(16, 'Miguel', 'Sanchez', '1111 Cedar St', 'Havana', '10400', '+53-7-555-6789', 'miguelsanchez@example.com'),
(17, 'Raúl', 'Gómez', '1212 Birch St', 'Varadero', '42200', '+53-45-555-4321', 'raulgomez@example.com'),
(18, 'Claudia', 'Diaz', '1313 Pine St', 'Santiago de Cuba', '90100', '+53-22-555-9876', 'claudiadiaz@example.com'),
(19, 'Felix', 'Rivera', '1414 Fir St', 'Holguín', '81100', '+53-24-555-2468', 'felixrivera@example.com'),
(20, 'Luisa', 'Fernandez', '1515 Oak St', 'Santa Clara', '50100', '+53-42-555-6789', 'luisafernandez@example.com'),
(21, 'Carlos', 'Mora', '1616 Maple St', 'Guatemala City', '01001', '+502-5555-1234', 'carlosmora@example.com'),
(22, 'Sofia', 'Hernández', '1717 Birch St', 'Antigua Guatemala', '03001', '+502-5555-6789', 'sofiahernandez@example.com'),
(23, 'Javier', 'Garcia', '1818 Cedar St', 'Quetzaltenango', '09001', '+502-5555-2345', 'javiergarcia@example.com'),
(24, 'Adriana', 'Lopez', '1919 Pine St', 'Escuintla', '05001', '+502-5555-9876', 'adrianalopez@example.com'),
(25, 'Antonio', 'Rodriguez', '2020 Redwood St', 'Chimaltenango', '04001', '+502-5555-2468', 'antonioperez@example.com'),
(26, 'Lucas', 'de Oliveira', '2121 Fir St', 'São Paulo', '01000-000', '+55-11-5555-1234', 'lucasdeoliveira@example.com'),
(27, 'Maria', 'Costa', '2222 Oak St', 'Rio de Janeiro', '20000-000', '+55-21-5555-4321', 'mariacosta@example.com'),
(28, 'Rafael', 'Silva', '2323 Cedar St', 'Salvador', '40000-000', '+55-71-5555-5678', 'rafaelsilva@example.com'),
(29, 'Paula', 'Oliveira', '2424 Birch St', 'Belo Horizonte', '30100-000', '+55-31-5555-2345', 'paulaoliveira@example.com'),
(30, 'Lucas', 'Santos', '2525 Pine St', 'Curitiba', '80000-000', '+55-41-5555-2468', 'lucassantos@example.com'),
(31, 'Lucia', 'Martins', '2626 Redwood St', 'Buenos Aires', 'C1000', '+54-11-5555-6789', 'luciamartins@example.com'),
(32, 'Carlos', 'Perez', '2727 Fir St', 'Cordoba', '5000', '+54-351-555-9876', 'carlosperez@example.com'),
(33, 'Ana', 'Rojas', '2828 Oak St', 'Rosario', '2000', '+54-341-555-2468', 'anarojas@example.com'),
(34, 'Pedro', 'Gonzalez', '2929 Maple St', 'Mendoza', '5500', '+54-261-555-4321', 'pedrogonzalez@example.com'),
(35, 'Gabriela', 'Vega', '3030 Birch St', 'Tucumán', '4000', '+54-381-555-1234', 'gabrielavega@example.com'),
(36, 'Sebastian', 'Arias', '3131 Pine St', 'Bogotá', '110111', '+57-1-555-9876', 'sebastianarias@example.com'),
(37, 'Valentina', 'Castro', '3232 Redwood St', 'Medellín', '050010', '+57-4-555-2468', 'valentinacastro@example.com'),
(38, 'Juan', 'Garcia', '3333 Fir St', 'Cali', '760010', '+57-2-555-6789', 'juangarcia@example.com'),
(39, 'Natalia', 'Fernández', '3434 Oak St', 'Barranquilla', '080010', '+57-5-555-2345', 'nataliafernandez@example.com'),
(40, 'Andrés', 'Moreno', '3535 Cedar St', 'Cartagena', '130010', '+57-5-555-4321', 'andresmoreno@example.com'),
(41, 'Matías', 'González', '3636 Pine St', 'Santiago', '8320000', '+56-2-555-1234', 'matiasgonzalez@example.com'),
(42, 'Fernanda', 'López', '3737 Redwood St', 'Valparaíso', '2340000', '+56-32-555-5678', 'fernandalópez@example.com'),
(43, 'Ignacio', 'Martínez', '3838 Fir St', 'Concepción', '4070000', '+56-41-555-2345', 'ignaciomartinez@example.com'),
(44, 'Antonio', 'Rodríguez', '3939 Oak St', 'La Serena', '1700000', '+56-51-555-9876', 'antoniorodriguez@example.com'),
(45, 'Valeria', 'Hernández', '4040 Maple St', 'Antofagasta', '1240000', '+56-55-555-2468', 'valeriahernandez@example.com'),
(46, 'Alejandro', 'Muñoz', '4141 Birch St', 'Lima', '15000', '+51-1-555-4321', 'alejandromunoz@example.com'),
(47, 'Lucía', 'Pérez', '4242 Redwood St', 'Arequipa', '04000', '+51-54-555-1234', 'luciaperez@example.com'),
(48, 'José', 'Rojas', '4343 Fir St', 'Cusco', '08000', '+51-84-555-5678', 'joserojas@example.com'),
(49, 'Carlos', 'Alvarez', '4444 Oak St', 'Trujillo', '13000', '+51-44-555-2345', 'carlosalvarez@example.com'),
(50, 'Juliana', 'Sánchez', '4545 Cedar St', 'Chiclayo', '14000', '+51-74-555-9876', 'julianasanchez@example.com'),
(51, 'Oliver', 'Brown', '4646 Pine St', 'London', 'E1 6AN', '+44-20-5555-6789', 'oliverbrown@example.com'),
(52, 'Emily', 'Johnson', '4747 Birch St', 'Manchester', 'M1 1AA', '+44-161-555-2468', 'emilyjohnson@example.com'),
(53, 'Jack', 'Taylor', '4848 Cedar St', 'Bristol', 'BS1 1AF', '+44-117-555-1357', 'jacktaylor@example.com'),
(54, 'Charlotte', 'Davis', '4949 Redwood St', 'Edinburgh', 'EH1 1RQ', '+44-131-555-1234', 'charlottedavis@example.com'),
(55, 'Alexander', 'Miller', '5050 Fir St', 'Berlin', '10115', '+49-30-5555-9876', 'alexandermiller@example.com'),
(56, 'Sophia', 'Schmidt', '5151 Oak St', 'Munich', '80331', '+49-89-5555-4321', 'sophiaschmidt@example.com'),
(57, 'Max', 'Weber', '5252 Maple St', 'Hamburg', '20095', '+49-40-5555-2468', 'maxweber@example.com'),
(58, 'Mia', 'Müller', '5353 Pine St', 'Cologne', '50667', '+49-221-555-6789', 'miamüller@example.com'),
(59, 'Paul', 'Schneider', '5454 Birch St', 'Frankfurt', '60311', '+49-69-5555-1234', 'paulschneider@example.com'),
(60, 'Lena', 'Fischer', '5555 Cedar St', 'Oslo', '0161', '+47-21-555-9876', 'lenafischer@example.com'),
(61, 'Henrik', 'Jensen', '5656 Oak St', 'Bergen', '5000', '+47-55-555-4321', 'henrikjensen@example.com'),
(62, 'Olivia', 'Larsen', '5757 Maple St', 'Stavanger', '4005', '+47-51-555-2468', 'olivialarsen@example.com'),
(63, 'Morten', 'Pedersen', '5858 Redwood St', 'Trondheim', '7000', '+47-73-555-1234', 'mortenpedersen@example.com'),
(64, 'Emil', 'Hansen', '5959 Fir St', 'Drammen', '3045', '+47-32-555-5678', 'emilhansen@example.com'),
(65, 'Elsa', 'Andersen', '6060 Oak St', 'Stockholm', '11120', '+46-8-555-2345', 'elsaandersen@example.com'),
(66, 'Vera', 'Karlsson', '6161 Pine St', 'Gothenburg', '41105', '+46-31-555-9876', 'verakarlsson@example.com'),
(67, 'Lucas', 'Larsson', '6262 Cedar St', 'Malmö', '21120', '+46-40-555-2468', 'lucaslarsson@example.com'),
(68, 'Ingrid', 'Olsson', '6363 Redwood St', 'Uppsala', '75330', '+46-18-555-4321', 'ingridolsson@example.com'),
(69, 'Arvid', 'Svensson', '6464 Fir St', 'Lund', '22350', '+46-46-555-1234', 'arvidsvensson@example.com'),
(70, 'Victor', 'Nilsen', '6565 Oak St', 'Copenhagen', '1000', '+45-33-555-5678', 'victornilsen@example.com'),
(71, 'Sophie', 'Pedersen', '6666 Maple St', 'Aarhus', '8000', '+45-89-555-2468', 'sophiepedersen@example.com'),
(72, 'Frederik', 'Jørgensen', '6767 Birch St', 'Odense', '5000', '+45-66-555-4321', 'frederikjorgensen@example.com'),
(73, 'Amalie', 'Christensen', '6868 Pine St', 'Aalborg', '9000', '+45-98-555-6789', 'amaliechristensen@example.com'),
(74, 'Emil', 'Thomsen', '6969 Redwood St', 'Esbjerg', '6700', '+45-75-555-2345', 'emilthomsen@example.com'),
(75, 'Giulia', 'Rossi', '7070 Fir St', 'Rome', '00100', '+39-06-5555-2468', 'giuliarossi@example.com'),
(76, 'Marco', 'Bianchi', '7171 Oak St', 'Milan', '20100', '+39-02-5555-9876', 'marcobianchi@example.com'),
(77, 'Francesca', 'Ferrari', '7272 Maple St', 'Florence', '50100', '+39-055-555-4321', 'francescaferrari@example.com'),
(78, 'Luca', 'Giordano', '7373 Pine St', 'Naples', '80100', '+39-081-5555-1234', 'lucagiordano@example.com'),
(79, 'Alessandro', 'Conti', '7474 Birch St', 'Bologna', '40100', '+39-051-555-5678', 'alessandroconti@example.com'),
(80, 'Juan', 'Martinez', '7575 Cedar St', 'Madrid', '28001', '+34-91-5555-2468', 'juanmartinez@example.com'),
(81, 'Maria', 'García', '7676 Redwood St', 'Barcelona', '08001', '+34-93-5555-4321', 'mariagarcia@example.com'),
(82, 'Carlos', 'Lopez', '7777 Fir St', 'Valencia', '46001', '+34-96-5555-1234', 'carloslopez@example.com'),
(83, 'Laura', 'Rodríguez', '7878 Oak St', 'Seville', '41001', '+34-95-5555-9876', 'laurarodriguez@example.com'),
(84, 'Antonio', 'Sánchez', '7979 Maple St', 'Bilbao', '48001', '+34-94-5555-2468', 'antoniosanchez@example.com'),
(85, 'Pierre', 'Lemoine', '8080 Birch St', 'Paris', '75001', '+33-1-5555-4321', 'pierrelimoine@example.com'),
(86, 'Sophie', 'Durand', '8181 Cedar St', 'Marseille', '13001', '+33-4-5555-2468', 'sophiedurand@example.com'),
(87, 'Julien', 'Martin', '8282 Redwood St', 'Lyon', '69001', '+33-4-5555-6789', 'julienmartin@example.com'),
(88, 'Camille', 'Lemoine', '8383 Fir St', 'Toulouse', '31000', '+33-5-5555-9876', 'camillelemoine@example.com'),
(89, 'Nicolas', 'Benoit', '8484 Oak St', 'Nice', '06000', '+33-4-5555-1234', 'nicolasbenoit@example.com'),
(90, 'Maria', 'Silva', '8585 Maple St', 'Lisbon', '1100-000', '+351-21-555-2468', 'mariasilva@example.com'),
(91, 'Pedro', 'Gomes', '8686 Birch St', 'Porto', '4000-000', '+351-22-555-4321', 'pedrogomes@example.com'),
(92, 'Beatriz', 'Martins', '8787 Cedar St', 'Faro', '8000-000', '+351-28-5555-1234', 'beatrizmartins@example.com'),
(93, 'André', 'Pereira', '8888 Redwood St', 'Coimbra', '3000-000', '+351-23-5555-9876', 'andrepereira@example.com'),
(94, 'Catarina', 'Ferreira', '8989 Pine St', 'Braga', '4700-000', '+351-25-5555-2468', 'catarinaferreira@example.com'),
(95, 'Dimitrios', 'Papadopoulos', '9090 Fir St', 'Athens', '10558', '+30-21-5555-6789', 'dimitriospapadopoulos@example.com'),
(96, 'Elena', 'Nikolaou', '9191 Oak St', 'Thessaloniki', '54625', '+30-231-555-1234', 'elena nikolaou@example.com'),
(97, 'Vasilis', 'Zervas', '9292 Maple St', 'Patras', '26221', '+30-261-555-9876', 'vasiliszervas@example.com'),
(98, 'Ioannis', 'Kouros', '9393 Birch St', 'Heraklion', '71201', '+30-281-555-2468', 'ioanniskouros@example.com'),
(99, 'Maria', 'Papadopoulou', '9494 Redwood St', 'Larissa', '41335', '+30-241-555-4321', 'mariapapadopoulou@example.com'),
(100, 'Kostas', 'Ioannidis', '9595 Pine St', 'Heraklion', '71201', '+30-281-555-2468', 'kostasioannidis@example.com'),
(101, 'Lena', 'Vasilenko', '9696 Fir St', 'Beijing', '100000', '+86-10-5555-1234', 'lenavasilenko@example.com'),
(102, 'Zhang', 'Wei', '9797 Oak St', 'Shanghai', '200000', '+86-21-5555-9876', 'zhangwei@example.com'),
(103, 'Xiu', 'Li', '9898 Maple St', 'Guangzhou', '510000', '+86-20-5555-2468', 'xiuli@example.com'),
(104, 'Li', 'Wang', '9999 Birch St', 'Shenzhen', '518000', '+86-755-555-4321', 'liwang@example.com'),
(105, 'Fang', 'Zhao', '10000 Redwood St', 'Chengdu', '610000', '+86-28-5555-6789', 'fangzhao@example.com'),
(106, 'Ravi', 'Sharma', '10101 Fir St', 'Mumbai', '400001', '+91-22-5555-1234', 'ravisharma@example.com'),
(107, 'Amit', 'Gupta', '10202 Oak St', 'Delhi', '110001', '+91-11-5555-9876', 'amitgupta@example.com'),
(108, 'Priya', 'Singh', '10303 Maple St', 'Bangalore', '560001', '+91-80-5555-2468', 'priyasingh@example.com'),
(109, 'Kavita', 'Chaudhary', '10404 Birch St', 'Chennai', '600001', '+91-44-5555-4321', 'kavitachaudhary@example.com'),
(110, 'Sanjay', 'Patel', '10505 Redwood St', 'Kolkata', '700001', '+91-33-5555-1234', 'sanjaypatel@example.com'),
(111, 'Taro', 'Yamamoto', '10606 Fir St', 'Tokyo', '100-0001', '+81-3-5555-9876', 'taroyamamoto@example.com'),
(112, 'Yuki', 'Takeda', '10707 Oak St', 'Osaka', '530-0001', '+81-6-5555-4321', 'yukitakeda@example.com'),
(113, 'Hiroshi', 'Sato', '10808 Maple St', 'Kyoto', '600-8001', '+81-75-5555-2468', 'hiroshisato@example.com'),
(114, 'Keiko', 'Nakamura', '10909 Birch St', 'Yokohama', '231-0001', '+81-45-5555-1234', 'keikonakamura@example.com'),
(115, 'Shinya', 'Kobayashi', '11010 Redwood St', 'Sapporo', '060-0001', '+81-11-5555-9876', 'shinyakobayashi@example.com'),
(116, 'Seojin', 'Kim', '11111 Fir St', 'Seoul', '04500', '+82-2-5555-1234', 'seojinkim@example.com'),
(117, 'Minji', 'Lee', '11212 Oak St', 'Busan', '48500', '+82-51-5555-9876', 'minjilee@example.com'),
(118, 'Jiho', 'Park', '11313 Maple St', 'Incheon', '400-000', '+82-32-5555-4321', 'jihopark@example.com'),
(119, 'Jiwon', 'Choi', '11414 Birch St', 'Daegu', '415-000', '+82-53-5555-2468', 'jiwonchoi@example.com'),
(120, 'Yejin', 'Jeong', '11515 Redwood St', 'Gwangju', '612-000', '+82-62-5555-6789', 'yejinjeong@example.com'),
(121, 'Nathapong', 'Chai', '11616 Fir St', 'Bangkok', '10100', '+66-2-5555-1234', 'nathapongchai@example.com'),
(122, 'Siriwan', 'Sutthirak', '11717 Oak St', 'Chiang Mai', '50200', '+66-53-5555-9876', 'siriwansutthirak@example.com'),
(123, 'Somchai', 'Wongphakdee', '11818 Maple St', 'Phuket', '83000', '+66-76-5555-2468', 'somchaiwongphakdee@example.com'),
(124, 'Pimchanok', 'Chirathivat', '11919 Birch St', 'Pattaya', '20150', '+66-38-5555-4321', 'pimchanokchirathivat@example.com'),
(125, 'Thasanee', 'Kongthong', '12020 Redwood St', 'Ayutthaya', '13000', '+66-35-5555-6789', 'thasaneekongthong@example.com'),
(126, 'Rafael', 'Lopez', '12121 Pine St', 'Mexico City', '01000', '+52-55-5555-1234', 'rafaellopez@example.com'),
(127, 'María', 'González', '12222 Cedar St', 'Guadalajara', '44100', '+52-33-5555-9876', 'mariagonzalez@example.com'),
(128, 'Carlos', 'Martínez', '12323 Redwood St', 'Monterrey', '64000', '+52-81-5555-2468', 'carlosmartinez@example.com'),
(129, 'Ana', 'Hernández', '12424 Fir St', 'Cancun', '77500', '+52-998-5555-4321', 'anahernandez@example.com'),
(130, 'José', 'Ramírez', '12525 Oak St', 'Puebla', '72000', '+52-222-5555-6789', 'joseramirez@example.com'),
(131, 'Laura', 'Rodríguez', '12626 Maple St', 'Havana', '10400', '+53-7-5555-1234', 'laurarodriguez@example.com'),
(132, 'Pedro', 'García', '12727 Birch St', 'Varadero', '42200', '+53-45-5555-9876', 'pedrogarcia@example.com'),
(133, 'Miguel', 'Sánchez', '12828 Redwood St', 'Santiago de Cuba', '90100', '+53-22-5555-2468', 'miguelsanchez@example.com'),
(134, 'Ana', 'López', '12929 Fir St', 'Holguín', '80100', '+53-24-5555-4321', 'analópez@example.com'),
(135, 'Luis', 'Morales', '13030 Oak St', 'Santa Clara', '50100', '+53-42-5555-6789', 'luismorales@example.com'),
(136, 'Miguel', 'González', '13131 Maple St', 'Guatemala City', '01001', '+502-2-5555-1234', 'miguelgonzalez@example.com'),
(137, 'Carlos', 'Mendoza', '13232 Birch St', 'Antigua Guatemala', '03001', '+502-5-5555-9876', 'carlosmendoza@example.com'),
(138, 'Marta', 'Rodríguez', '13333 Redwood St', 'Quetzaltenango', '09001', '+502-7-5555-2468', 'martarodriguez@example.com'),
(139, 'Ricardo', 'López', '13434 Fir St', 'Escuintla', '07001', '+502-4-5555-4321', 'ricardolopez@example.com'),
(140, 'Carlos', 'Ramírez', '13535 Oak St', 'Chimaltenango', '04001', '+502-6-5555-6789', 'carlosramirez@example.com'),
(141, 'Isabela', 'Silva', '13636 Maple St', 'São Paulo', '01000-000', '+55-11-5555-1234', 'isabelasilva@example.com'),
(142, 'Lucas', 'Costa', '13737 Birch St', 'Rio de Janeiro', '20000-000', '+55-21-5555-9876', 'lucascosta@example.com'),
(143, 'Camila', 'Oliveira', '13838 Redwood St', 'Salvador', '40000-000', '+55-71-5555-2468', 'camilaoliveira@example.com'),
(144, 'João', 'Souza', '13939 Fir St', 'Belo Horizonte', '30100-000', '+55-31-5555-4321', 'joãosouza@example.com'),
(145, 'Ana', 'Santos', '14040 Oak St', 'Curitiba', '80000-000', '+55-41-5555-6789', 'anasantos@example.com'),
(146, 'Juan', 'Fernández', '14141 Maple St', 'Buenos Aires', 'C1000', '+54-11-5555-1234', 'juanfernandez@example.com'),
(147, 'Lucía', 'Gómez', '14242 Birch St', 'Cordoba', '5000', '+54-351-5555-9876', 'luciagomez@example.com'),
(148, 'José', 'Vega', '14343 Redwood St', 'Rosario', '2000', '+54-341-5555-2468', 'josevega@example.com'),
(149, 'Santiago', 'Martínez', '14444 Fir St', 'Mendoza', '5500', '+54-261-5555-4321', 'santiagomartinez@example.com'),
(150, 'Valentina', 'Pérez', '14545 Oak St', 'Tucumán', '4000', '+54-381-5555-6789', 'valentinaperez@example.com'),
(151, 'Carlos', 'González', '14646 Maple St', 'Bogotá', '110111', '+57-1-5555-1234', 'carlosgonzalez@example.com'),
(152, 'Alejandra', 'Ramírez', '14747 Birch St', 'Medellín', '050001', '+57-4-5555-9876', 'alejandraramirez@example.com'),
(153, 'David', 'Suárez', '14848 Redwood St', 'Cali', '760001', '+57-2-5555-2468', 'davidsuarez@example.com'),
(154, 'Lucía', 'Pérez', '14949 Fir St', 'Barranquilla', '080001', '+57-5-5555-4321', 'luciaperez@example.com'),
(155, 'Felipe', 'Martínez', '15050 Oak St', 'Cartagena', '130001', '+57-5-5555-6789', 'felipemartinez@example.com'),
(156, 'Esteban', 'Mendoza', '15151 Maple St', 'Santiago', '8320000', '+56-2-5555-1234', 'estebanmendoza@example.com'),
(157, 'Paula', 'Vega', '15252 Birch St', 'Valparaíso', '2340000', '+56-32-5555-9876', 'paulavega@example.com'),
(158, 'Nicolás', 'Rojas', '15353 Redwood St', 'Concepción', '4070000', '+56-41-5555-2468', 'nicolasrojas@example.com'),
(159, 'Martín', 'González', '15454 Fir St', 'La Serena', '1700000', '+56-51-5555-4321', 'martingonzalez@example.com'),
(160, 'Andrés', 'López', '15555 Oak St', 'Antofagasta', '1240000', '+56-55-5555-6789', 'andreslopez@example.com'),
(161, 'Camila', 'Gómez', '15656 Maple St', 'Lima', '15000', '+51-1-5555-1234', 'camilagomez@example.com'),
(162, 'Carlos', 'Jiménez', '15757 Birch St', 'Arequipa', '04000', '+51-54-5555-9876', 'carlosjimenez@example.com'),
(163, 'Juan', 'Mendoza', '15858 Redwood St', 'Cusco', '08000', '+51-84-5555-2468', 'juanmendoza@example.com'),
(164, 'María', 'Martínez', '15959 Fir St', 'Trujillo', '13000', '+51-44-5555-4321', 'mariama@example.com'),
(165, 'José', 'Ramírez', '16060 Oak St', 'Chiclayo', '14000', '+51-74-5555-6789', 'joseramirez@example.com'),
(166, 'John', 'Doe', '16161 Maple St', 'London', 'E1 6AN', '+44-20-5555-1234', 'johndoe@example.com'),
(167, 'Sarah', 'Smith', '16262 Birch St', 'Manchester', 'M1 1AE', '+44-161-5555-9876', 'sarahsmith@example.com'),
(168, 'Michael', 'Johnson', '16363 Redwood St', 'Bristol', 'BS1 1LJ', '+44-117-5555-2468', 'michaeljohnson@example.com'),
(169, 'Emma', 'Williams', '16464 Fir St', 'Edinburgh', 'EH1 2QL', '+44-131-5555-4321', 'emmawilliams@example.com'),
(170, 'Liam', 'Brown', '16565 Oak St', 'Berlin', '10115', '+49-30-5555-1234', 'liambrown@example.com'),
(171, 'Olivia', 'Davis', '16666 Maple St', 'Munich', '80331', '+49-89-5555-9876', 'oliviadavis@example.com'),
(172, 'Noah', 'Miller', '16767 Birch St', 'Hamburg', '20095', '+49-40-5555-2468', 'noahmiller@example.com'),
(173, 'Sophia', 'Wilson', '16868 Redwood St', 'Cologne', '50667', '+49-221-5555-4321', 'sophiawilson@example.com'),
(174, 'James', 'Moore', '16969 Fir St', 'Frankfurt', '60311', '+49-69-5555-6789', 'jamesmoore@example.com'),
(175, 'Isabella', 'Taylor', '17070 Oak St', 'Oslo', '0150', '+47-22-5555-1234', 'isabellataylor@example.com'),
(176, 'William', 'Andersen', '17171 Maple St', 'Bergen', '5000', '+47-55-5555-9876', 'williamandersen@example.com'),
(177, 'Charlotte', 'Olsen', '17272 Birch St', 'Stavanger', '4005', '+47-51-5555-2468', 'charlotteolsen@example.com'),
(178, 'Henry', 'Nilsen', '17373 Redwood St', 'Trondheim', '7013', '+47-73-5555-4321', 'henrynilsen@example.com'),
(179, 'Amelia', 'Johansen', '17474 Fir St', 'Drammen', '3004', '+47-32-5555-6789', 'ameliajohansen@example.com'),
(180, 'Lucas', 'Jensen', '17575 Oak St', 'Stockholm', '111 47', '+46-8-5555-1234', 'lucasjensen@example.com'),
(181, 'Emma', 'Karlsson', '17676 Maple St', 'Gothenburg', '411 22', '+46-31-5555-9876', 'emmakarlsson@example.com'),
(182, 'Elias', 'Larsson', '17777 Birch St', 'Malmö', '211 22', '+46-40-5555-2468', 'eliaslarsson@example.com'),
(183, 'Isabella', 'Eriksson', '17878 Redwood St', 'Uppsala', '753 20', '+46-18-5555-4321', 'isabellaeriksson@example.com'),
(184, 'Oskar', 'Svensson', '17979 Fir St', 'Lund', '223 50', '+46-46-5555-6789', 'oskarsvensson@example.com'),
(185, 'Alice', 'Hansson', '18080 Oak St', 'Copenhagen', '1000', '+45-33-5555-1234', 'alicehansson@example.com'),
(186, 'Elias', 'Jørgensen', '18181 Maple St', 'Aarhus', '8000', '+45-87-5555-9876', 'eliasjorgensen@example.com'),
(187, 'Nora', 'Petersen', '18282 Birch St', 'Odense', '5000', '+45-66-5555-2468', 'norapetersen@example.com'),
(188, 'Victor', 'Madsen', '18383 Redwood St', 'Aalborg', '9000', '+45-98-5555-4321', 'victormadsen@example.com'),
(189, 'Maja', 'Christensen', '18484 Fir St', 'Esbjerg', '6700', '+45-75-5555-6789', 'majachristensen@example.com'),
(190, 'Gustav', 'Johansen', '18585 Oak St', 'Rome', '00100', '+39-06-5555-1234', 'gustavjohansen@example.com'),
(191, 'Chiara', 'Ricci', '18686 Maple St', 'Milan', '20100', '+39-02-5555-9876', 'chiararicci@example.com'),
(192, 'Luca', 'Bianchi', '18787 Birch St', 'Florence', '50100', '+39-055-5555-2468', 'lucabianchi@example.com'),
(193, 'Giulia', 'Verdi', '18888 Redwood St', 'Naples', '80100', '+39-081-5555-4321', 'giuliaverdi@example.com'),
(194, 'Leonardo', 'Esposito', '18989 Fir St', 'Bologna', '40100', '+39-051-5555-6789', 'leonardoesposito@example.com'),
(195, 'Sofia', 'Russo', '19090 Oak St', 'Madrid', '28001', '+34-91-5555-1234', 'sofiarusso@example.com'),
(196, 'Carlos', 'Fernández', '19191 Maple St', 'Barcelona', '08001', '+34-93-5555-9876', 'carlosfernandez@example.com'),
(197, 'María', 'López', '19292 Birch St', 'Valencia', '46001', '+34-96-5555-2468', 'marialopez@example.com'),
(198, 'José', 'González', '19393 Redwood St', 'Seville', '41001', '+34-95-5555-4321', 'josegonzalez@example.com'),
(199, 'Ana', 'Martínez', '19494 Fir St', 'Bilbao', '48001', '+34-94-5555-6789', 'anamartinez@example.com'),
(200, 'Manuel', 'Sánchez', '19595 Oak St', 'Paris', '75001', '+33-1-5555-1234', 'manuelsanchez@example.com'),
(201, 'Marie', 'Dupont', '19696 Maple St', 'Marseille', '13001', '+33-4-5555-9876', 'mariedupont@example.com'),
(202, 'Pierre', 'Lemoine', '19797 Birch St', 'Lyon', '69001', '+33-4-5555-2468', 'pierremartin@example.com'),
(203, 'Sophie', 'Lemoine', '19898 Redwood St', 'Toulouse', '31000', '+33-5-5555-4321', 'sophielemoine@example.com'),
(204, 'Claire', 'Bernard', '19999 Fir St', 'Nice', '06000', '+33-4-5555-6789', 'clairebernard@example.com'),
(205, 'Pedro', 'Sousa', '20000 Oak St', 'Lisbon', '1000-001', '+351-21-5555-1234', 'pedrosousa@example.com'),
(206, 'Joana', 'Pereira', '20101 Maple St', 'Porto', '4000-001', '+351-22-5555-9876', 'joanapereira@example.com'),
(207, 'António', 'Costa', '20202 Birch St', 'Faro', '8000-001', '+351-28-5555-2468', 'antoniocosta@example.com'),
(208, 'Carlos', 'Almeida', '20303 Redwood St', 'Coimbra', '3000-001', '+351-23-5555-4321', 'carlosalmeida@example.com'),
(209, 'Maria', 'Rodrigues', '20404 Fir St', 'Braga', '4700-001', '+351-25-5555-6789', 'mariarodrigues@example.com'),
(210, 'Ioannis', 'Papadopoulos', '20505 Oak St', 'Athens', '10558', '+30-21-5555-1234', 'ioannispapadopoulos@example.com'),
(211, 'Dimitra', 'Nikolaou', '20606 Maple St', 'Thessaloniki', '54625', '+30-231-5555-9876', 'dimitranikolaou@example.com'),
(212, 'Alexandros', 'Kostas', '20707 Birch St', 'Patras', '26221', '+30-2610-5555-2468', 'alexandroskostas@example.com'),
(213, 'Evangelia', 'Karagianni', '20808 Redwood St', 'Heraklion', '71202', '+30-2810-5555-4321', 'evangeliaKaragianni@example.com'),
(214, 'Nikos', 'Papadopoulos', '20909 Fir St', 'Larissa', '41222', '+30-2410-5555-6789', 'nikospapadopoulos@example.com'),
(215, 'Vasilis', 'Kokkinos', '21010 Oak St', 'Heraklion', '71304', '+30-2810-5555-1234', 'vasiliskokkinos@example.com'),
(216, 'Wei', 'Li', '21111 Maple St', 'Beijing', '100000', '+86-10-5555-9876', 'weili@example.com'),
(217, 'Ming', 'Wang', '21212 Birch St', 'Shanghai', '200000', '+86-21-5555-2468', 'mingwang@example.com'),
(218, 'Ying', 'Zhang', '21313 Redwood St', 'Guangzhou', '510000', '+86-20-5555-4321', 'yingzhang@example.com'),
(219, 'Hua', 'Chen', '21414 Fir St', 'Shenzhen', '518000', '+86-755-5555-6789', 'huachen@example.com'),
(220, 'Liu', 'Yang', '21515 Oak St', 'Chengdu', '610000', '+86-28-5555-1234', 'liuyang@example.com'),
(221, 'Arjun', 'Sharma', '21616 Maple St', 'Mumbai', '400001', '+91-22-5555-9876', 'arjunsharma@example.com'),
(222, 'Priya', 'Patel', '21717 Birch St', 'Delhi', '110001', '+91-11-5555-2468', 'priyapatel@example.com'),
(223, 'Rahul', 'Verma', '21818 Redwood St', 'Bangalore', '560001', '+91-80-5555-4321', 'rahulverma@example.com'),
(224, 'Ananya', 'Reddy', '21919 Fir St', 'Chennai', '600001', '+91-44-5555-6789', 'ananyareddy@example.com'),
(225, 'Sandeep', 'Kumar', '22020 Oak St', 'Kolkata', '700001', '+91-33-5555-1234', 'sandeepkumar@example.com'),
(226, 'Haruto', 'Tanaka', '22121 Maple St', 'Tokyo', '100-0001', '+81-3-5555-9876', 'harutotanaka@example.com'),
(227, 'Yuki', 'Yamamoto', '22222 Birch St', 'Osaka', '530-0001', '+81-6-5555-2468', 'yukiyamamoto@example.com'),
(228, 'Emi', 'Sato', '22323 Redwood St', 'Kyoto', '600-0001', '+81-75-5555-4321', 'emisato@example.com'),
(229, 'Taro', 'Nakamura', '22424 Fir St', 'Yokohama', '231-0001', '+81-45-5555-6789', 'taronakamura@example.com'),
(230, 'Ichiro', 'Suzuki', '22525 Oak St', 'Sapporo', '060-0001', '+81-11-5555-1234', 'ichirosuzuki@example.com'),
(231, 'Jin', 'Park', '22626 Maple St', 'Seoul', '03000', '+82-2-5555-9876', 'jinpark@example.com'),
(232, 'Jisoo', 'Kim', '22727 Birch St', 'Busan', '60000', '+82-51-5555-2468', 'jisookim@example.com'),
(233, 'Soo', 'Lee', '22828 Redwood St', 'Incheon', '22000', '+82-32-5555-4321', 'soolee@example.com'),
(234, 'Kyung', 'Cho', '22929 Fir St', 'Daegu', '70200', '+82-53-5555-6789', 'kyungcho@example.com'),
(235, 'Minji', 'Jeong', '23030 Oak St', 'Gwangju', '61400', '+82-62-5555-1234', 'minjijeong@example.com'),
(236, 'Suri', 'Suk', '23131 Maple St', 'Bangkok', '10100', '+66-2-5555-9876', 'surisuk@example.com'),
(237, 'Somchai', 'Chai', '23232 Birch St', 'Chiang Mai', '50000', '+66-53-5555-2468', 'somchaichai@example.com'),
(238, 'Nok', 'Ying', '23333 Redwood St', 'Phuket', '83000', '+66-76-5555-4321', 'nokying@example.com'),
(239, 'Pachara', 'Tee', '23434 Fir St', 'Pattaya', '20150', '+66-38-5555-6789', 'pacharatee@example.com'),
(240, 'Kanya', 'Rattan', '23535 Oak St', 'Ayutthaya', '13000', '+66-35-5555-1234', 'kanyarattan@example.com'),
(241, 'Ben', 'Liang', '23636 Maple St', 'Beijing', '100020', '+86-10-5555-9876', 'benliang@example.com'),
(242, 'Lian', 'Zhao', '23737 Birch St', 'Shanghai', '200120', '+86-21-5555-2468', 'lianzhao@example.com'),
(243, 'Jing', 'Xu', '23838 Redwood St', 'Guangzhou', '510000', '+86-20-5555-4321', 'jingxu@example.com'),
(244, 'Wei', 'Yang', '23939 Fir St', 'Shenzhen', '518001', '+86-755-5555-6789', 'weiyang@example.com'),
(245, 'Yue', 'Wang', '24040 Oak St', 'Chengdu', '610001', '+86-28-5555-1234', 'yuewang@example.com'),
(246, 'Shivani', 'Desai', '24141 Maple St', 'Mumbai', '400101', '+91-22-5555-9876', 'shivanidesai@example.com'),
(247, 'Raj', 'Bhat', '24242 Birch St', 'Delhi', '110010', '+91-11-5555-2468', 'rajbhat@example.com'),
(248, 'Kavya', 'Sharma', '24343 Redwood St', 'Bangalore', '560102', '+91-80-5555-4321', 'kavyasharma@example.com'),
(249, 'Arvind', 'Kumar', '24444 Fir St', 'Chennai', '600100', '+91-44-5555-6789', 'arvindkumar@example.com'),
(250, 'Priyanka', 'Iyer', '24545 Oak St', 'Kolkata', '700019', '+91-33-5555-1234', 'priyankaiyer@example.com');


INSERT INTO sales (SaleID, SaleDate, ProductID, SalesPointID, CustomerID) 
VALUES

(1, '2024-10-03 15:42:00', 97, 80, 195),
(2, '2024-08-11 09:26:00', 5, 47, 47),
(3, '2022-12-15 18:14:00', 56, 110, 225),
(4, '2023-09-26 19:07:00', 86, 77, 77),
(5, '2023-11-03 20:31:00', 83, 112, 227),
(6, '2024-04-07 16:58:00', 59, 109, 224),
(7, '2022-12-17 11:23:00', 90, 32, 147),
(8, '2024-10-25 11:36:00', 5, 64, 179),
(9, '2023-03-02 13:58:00', 90, 25, 25),
(10, '2023-08-27 17:03:00', 22, 22, 22),
(11, '2024-07-20 18:47:00', 71, 92, 92),
(12, '2024-07-21 20:14:00', 54, 116, 116),
(13, '2024-05-18 14:21:00', 14, 12, 12),
(14, '2023-08-05 15:58:00', 87, 18, 18),
(15, '2025-01-05 17:25:00', 28, 73, 188),
(16, '2023-02-14 11:52:00', 18, 39, 154),
(17, '2024-08-22 19:43:00', 15, 80, 195),
(18, '2025-01-12 16:32:00', 68, 12, 12),
(19, '2023-01-17 15:27:00', 70, 92, 92),
(20, '2024-07-26 19:18:00', 26, 45, 45),
(21, '2024-09-02 09:32:00', 16, 121, 236),
(22, '2024-02-18 09:41:00', 70, 41, 156),
(23, '2024-10-07 17:45:00', 90, 78, 78),
(24, '2023-10-21 09:19:00', 42, 88, 88),
(25, '2023-01-01 14:47:00', 87, 112, 112),
(26, '2024-02-26 15:31:00', 1, 91, 91),
(27, '2024-05-27 17:54:00', 53, 111, 226),
(28, '2024-01-06 11:36:00', 91, 1, 1),
(29, '2025-01-03 17:21:00', 13, 103, 103),
(30, '2023-12-28 09:11:00', 88, 86, 201),
(31, '2024-05-04 09:34:00', 74, 96, 96),
(32, '2023-02-07 18:54:00', 87, 11, 11),
(33, '2023-02-27 13:12:00', 4, 102, 217),
(34, '2023-03-23 12:26:00', 67, 116, 231),
(35, '2023-07-27 20:11:00', 10, 122, 237),
(36, '2024-11-01 15:08:00', 59, 86, 86),
(37, '2024-11-02 19:53:00', 4, 78, 78),
(38, '2023-10-29 09:34:00', 17, 120, 235),
(39, '2023-11-23 09:07:00', 48, 95, 210),
(40, '2024-08-23 13:23:00', 11, 104, 104),
(41, '2024-10-30 20:41:00', 92, 22, 137),
(42, '2025-01-15 10:32:00', 42, 95, 210),
(43, '2023-08-26 13:21:00', 31, 121, 236),
(44, '2023-05-22 11:51:00', 7, 88, 88),
(45, '2023-04-17 18:59:00', 36, 91, 91),
(46, '2024-09-23 17:53:00', 94, 96, 96),
(47, '2023-08-19 18:35:00', 50, 54, 169),
(48, '2023-07-20 17:11:00', 48, 78, 193),
(49, '2024-07-21 14:25:00', 34, 33, 33),
(50, '2023-12-20 20:05:00', 47, 29, 144),
(51, '2023-09-20 11:45:00', 36, 124, 124),
(52, '2023-06-17 15:37:00', 84, 59, 59),
(53, '2023-08-17 09:12:00', 44, 95, 210),
(54, '2024-07-23 12:37:00', 67, 21, 21),
(55, '2024-04-26 14:19:00', 20, 124, 124),
(56, '2024-06-28 16:11:00', 78, 94, 209),
(57, '2023-10-06 12:42:00', 76, 64, 64),
(58, '2024-03-18 18:06:00', 12, 125, 240),
(59, '2022-12-27 17:33:00', 75, 41, 41),
(60, '2023-08-31 11:28:00', 26, 42, 42),
(61, '2023-09-23 18:18:00', 54, 50, 165),
(62, '2023-05-13 10:03:00', 73, 57, 172),
(63, '2023-09-27 12:58:00', 32, 87, 202),
(64, '2023-05-22 14:46:00', 45, 55, 55),
(65, '2023-09-22 09:27:00', 90, 15, 15),
(66, '2024-11-10 13:33:00', 73, 65, 65),
(67, '2024-01-13 18:45:00', 10, 101, 241),
(68, '2024-02-19 10:22:00', 33, 35, 35),
(69, '2024-01-05 17:01:00', 29, 116, 231),
(70, '2023-04-16 09:47:00', 97, 4, 4),
(71, '2024-05-29 09:34:00', 24, 97, 212),
(72, '2023-05-03 18:33:00', 46, 92, 92),
(73, '2023-12-25 15:15:00', 56, 86, 201),
(74, '2023-06-28 20:25:00', 48, 114, 229),
(75, '2023-11-05 13:56:00', 49, 63, 178),
(76, '2023-01-21 11:47:00', 49, 90, 205),
(77, '2024-09-07 14:35:00', 92, 101, 101),
(78, '2023-09-11 17:27:00', 59, 45, 45),
(79, '2023-09-02 15:08:00', 73, 42, 157),
(80, '2024-04-16 18:16:00', 93, 71, 186),
(81, '2023-07-27 10:19:00', 82, 43, 158),
(82, '2024-08-23 13:47:00', 30, 90, 205),
(83, '2023-04-13 11:54:00', 9, 108, 223),
(84, '2023-03-31 18:03:00', 17, 100, 215),
(85, '2024-07-10 20:20:00', 67, 97, 212),
(86, '2023-06-22 16:40:00', 2, 79, 194),
(87, '2023-11-23 09:59:00', 77, 14, 129),
(88, '2024-11-18 12:30:00', 49, 11, 126),
(89, '2023-07-07 15:14:00', 11, 104, 244),
(90, '2024-11-29 11:22:00', 66, 113, 228),
(91, '2023-01-19 14:37:00', 16, 106, 246),
(92, '2024-09-30 10:28:00', 33, 11, 11),
(93, '2023-03-12 19:14:00', 98, 85, 85),
(94, '2024-09-04 18:46:00', 12, 101, 216),
(95, '2024-10-07 15:51:00', 60, 67, 67),
(96, '2023-12-29 14:15:00', 36, 84, 84),
(97, '2023-05-28 09:24:00', 39, 25, 25),
(98, '2024-05-13 13:38:00', 90, 23, 138),
(99, '2023-05-12 09:50:00', 27, 14, 129),
(100, '2024-11-25 13:28:00', 99, 9, 9),
(101, '2023-08-26 11:11:00', 96, 41, 156),
(102, '2024-07-07 10:32:00', 38, 117, 232),
(103, '2024-12-30 15:46:00', 46, 107, 222),
(104, '2022-12-02 18:39:00', 66, 79, 194),
(105, '2022-12-22 15:09:00', 61, 103, 243),
(106, '2024-12-12 17:41:00', 21, 56, 56),
(107, '2023-11-15 16:07:00', 82, 51, 166),
(108, '2024-06-28 18:22:00', 29, 113, 113),
(109, '2024-04-13 11:15:00', 83, 50, 165),
(110, '2023-09-18 17:45:00', 38, 9, 9),
(111, '2023-06-24 14:21:00', 93, 111, 111),
(112, '2024-05-06 20:05:00', 38, 31, 146),
(113, '2024-12-16 19:54:00', 75, 38, 38),
(114, '2023-10-15 14:12:00', 71, 118, 233),
(115, '2024-05-22 20:07:00', 99, 40, 155),
(116, '2023-07-11 18:59:00', 99, 98, 215),
(117, '2025-01-06 15:38:00', 3, 76, 191),
(118, '2024-10-31 13:42:00', 56, 11, 126),
(119, '2025-01-07 11:09:00', 39, 94, 94),
(120, '2023-10-14 11:24:00', 26, 78, 193),
(121, '2023-11-05 20:11:00', 60, 113, 113),
(122, '2024-12-31 13:34:00', 90, 84, 84),
(123, '2023-06-22 14:52:00', 21, 1, 1),
(124, '2023-01-20 11:26:00', 93, 101, 101),
(125, '2023-10-14 16:44:00', 83, 124, 124),
(126, '2024-07-05 15:13:00', 80, 1, 1),
(127, '2023-03-09 18:22:00', 35, 37, 37),
(128, '2024-01-10 18:41:00', 84, 107, 222),
(129, '2023-10-27 17:17:00', 76, 109, 109),
(130, '2024-05-16 18:46:00', 51, 75, 75),
(131, '2024-06-10 09:58:00', 38, 35, 35),
(132, '2023-11-16 12:33:00', 88, 112, 227),
(133, '2024-01-07 19:15:00', 23, 58, 173),
(134, '2024-12-21 20:14:00', 5, 52, 167),
(135, '2023-09-22 20:09:00', 53, 93, 208),
(136, '2024-01-25 14:35:00', 69, 115, 115),
(137, '2022-12-02 19:17:00', 92, 55, 55),
(138, '2023-10-03 15:28:00', 92, 115, 115),
(139, '2023-04-13 20:00:00', 70, 112, 227),
(140, '2024-07-19 14:16:00', 93, 92, 207),
(141, '2024-03-18 11:38:00', 11, 8, 8),
(142, '2023-10-19 16:05:00', 4, 68, 68),
(143, '2024-05-31 09:55:00', 6, 112, 112),
(144, '2022-12-10 12:39:00', 79, 105, 245),
(145, '2023-10-12 10:03:00', 19, 6, 6),
(146, '2024-11-20 14:53:00', 14, 110, 110),
(147, '2025-01-06 15:41:00', 30, 74, 189),
(148, '2023-02-20 09:06:00', 92, 53, 168),
(149, '2023-11-29 09:25:00', 98, 45, 160),
(150, '2024-09-23 18:51:00', 17, 42, 42),
(151, '2024-01-01 11:29:00', 74, 67, 182),
(152, '2024-10-13 16:32:00', 19, 101, 216),
(153, '2024-07-19 18:17:00', 59, 62, 62),
(154, '2024-11-06 09:49:00', 93, 88, 88),
(155, '2024-10-27 11:59:00', 46, 63, 178),
(156, '2023-07-14 20:19:00', 71, 43, 43),
(157, '2024-02-23 13:45:00', 58, 46, 161),
(158, '2024-05-03 09:38:00', 1, 19, 134),
(159, '2023-05-17 15:11:00', 3, 83, 198),
(160, '2024-04-15 19:54:00', 66, 19, 134),
(161, '2024-11-22 20:21:00', 2, 60, 175),
(162, '2024-05-21 10:47:00', 17, 123, 238),
(163, '2024-08-17 17:10:00', 78, 76, 76),
(164, '2024-05-24 13:53:00', 14, 59, 174),
(165, '2023-08-02 12:37:00', 20, 14, 129),
(166, '2023-08-30 09:12:00', 56, 36, 36),
(167, '2024-12-23 11:19:00', 42, 112, 227),
(168, '2024-01-17 18:54:00', 48, 77, 77),
(169, '2023-06-22 12:41:00', 78, 58, 58),
(170, '2023-05-03 16:17:00', 31, 13, 13),
(171, '2023-06-26 11:36:00', 54, 20, 135),
(172, '2023-12-15 19:07:00', 66, 113, 228),
(173, '2024-11-11 09:53:00', 20, 70, 70),
(174, '2024-01-25 14:23:00', 89, 83, 83),
(175, '2023-07-09 15:40:00', 56, 48, 163),
(176, '2023-08-11 16:09:00', 15, 124, 124),
(177, '2024-12-02 14:39:00', 42, 12, 127),
(178, '2023-05-23 17:22:00', 46, 30, 145),
(179, '2023-10-12 14:14:00', 65, 125, 125),
(180, '2023-10-20 10:26:00', 72, 24, 24),
(181, '2024-01-22 17:47:00', 45, 69, 184),
(182, '2024-09-25 20:03:00', 95, 107, 222),
(183, '2023-04-25 19:09:00', 50, 15, 15),
(184, '2024-05-04 18:12:00', 38, 37, 152),
(185, '2024-04-23 14:39:00', 58, 108, 223),
(186, '2023-04-03 12:23:00', 39, 76, 76),
(187, '2023-09-11 09:50:00', 19, 74, 189),
(188, '2023-09-16 13:32:00', 89, 27, 27),
(189, '2023-12-18 17:16:00', 28, 24, 139),
(190, '2023-04-12 20:15:00', 76, 108, 108),
(191, '2022-12-29 18:58:00', 8, 37, 37),
(192, '2024-11-02 20:07:00', 86, 59, 59),
(193, '2023-02-01 12:17:00', 46, 40, 40),
(194, '2024-10-23 19:11:00', 16, 92, 92),
(195, '2023-10-20 14:37:00', 75, 29, 144),
(196, '2023-12-20 11:21:00', 86, 79, 79),
(197, '2024-02-01 19:12:00', 42, 21, 136),
(198, '2024-07-08 15:39:00', 42, 103, 103),
(199, '2024-07-24 16:23:00', 93, 90, 90),
(200, '2022-12-09 09:14:00', 35, 29, 144),
(201, '2023-02-14 10:16:00', 84, 10, 10),
(202, '2023-05-12 11:32:00', 15, 98, 214),
(203, '2024-10-06 17:21:00', 34, 124, 239),
(204, '2023-12-03 12:55:00', 95, 70, 185),
(205, '2024-05-18 13:09:00', 56, 35, 150),
(206, '2024-03-27 19:05:00', 92, 16, 16),
(207, '2023-09-23 10:23:00', 47, 86, 201),
(208, '2024-06-16 19:53:00', 25, 15, 15),
(209, '2024-01-08 20:42:00', 21, 49, 49),
(210, '2023-03-18 09:59:00', 15, 119, 119),
(211, '2023-04-08 09:46:00', 7, 106, 106),
(212, '2023-09-21 12:11:00', 21, 111, 226),
(213, '2023-10-31 14:59:00', 73, 59, 174),
(214, '2023-01-17 13:36:00', 48, 23, 138),
(215, '2024-10-20 19:14:00', 78, 39, 39),
(216, '2024-05-05 19:29:00', 81, 65, 180),
(217, '2024-08-25 09:32:00', 82, 87, 202),
(218, '2023-06-21 12:41:00', 48, 64, 179),
(219, '2024-07-21 17:19:00', 74, 120, 120),
(220, '2024-04-28 16:17:00', 17, 33, 148),
(221, '2023-04-28 18:43:00', 5, 64, 64),
(222, '2023-02-21 17:57:00', 62, 52, 52),
(223, '2023-01-14 15:44:00', 72, 102, 102),
(224, '2024-01-17 10:28:00', 30, 88, 88),
(225, '2024-10-19 14:37:00', 76, 1, 1),
(226, '2022-12-10 17:11:00', 35, 47, 47),
(227, '2024-03-29 10:25:00', 81, 16, 131),
(228, '2024-02-04 09:36:00', 82, 63, 63),
(229, '2024-02-10 12:14:00', 10, 113, 228),
(230, '2023-07-15 15:25:00', 93, 10, 10),
(231, '2023-04-18 13:42:00', 7, 61, 176),
(232, '2024-05-24 17:10:00', 63, 46, 161),
(233, '2024-09-22 16:59:00', 72, 101, 216),
(234, '2024-02-09 13:43:00', 59, 78, 193),
(235, '2024-01-06 20:09:00', 95, 51, 166),
(236, '2023-10-31 16:38:00', 65, 14, 14),
(237, '2024-01-19 10:31:00', 79, 85, 85),
(238, '2024-07-07 11:12:00', 31, 75, 75),
(239, '2024-07-30 17:47:00', 11, 49, 164),
(240, '2023-05-19 13:51:00', 39, 90, 90),
(241, '2023-04-06 12:07:00', 52, 2, 2),
(242, '2023-08-09 10:48:00', 67, 79, 79),
(243, '2023-12-04 17:26:00', 67, 66, 181),
(244, '2024-12-18 19:35:00', 71, 48, 163),
(245, '2022-12-02 16:09:00', 6, 91, 206),
(246, '2023-11-08 19:55:00', 13, 105, 245),
(247, '2023-01-20 13:39:00', 49, 32, 147),
(248, '2024-03-05 10:51:00', 97, 78, 193),
(249, '2023-08-09 20:18:00', 53, 59, 59),
(250, '2024-03-26 09:48:00', 30, 96, 211),
(251, '2024-11-01 15:45:00', 55, 85, 200),
(252, '2023-12-21 11:07:00', 96, 45, 45),
(253, '2024-10-09 12:22:00', 28, 107, 222),
(254, '2022-12-05 17:03:00', 89, 24, 24),
(255, '2024-03-22 20:40:00', 55, 107, 222),
(256, '2023-03-02 18:44:00', 56, 26, 26),
(257, '2023-08-25 20:16:00', 47, 70, 70),
(258, '2024-05-19 12:59:00', 96, 89, 89),
(259, '2024-05-26 09:36:00', 79, 29, 144),
(260, '2023-08-01 19:25:00', 59, 42, 42),
(261, '2025-01-14 17:44:00', 19, 26, 26),
(262, '2023-11-03 09:39:00', 24, 66, 181),
(263, '2024-09-23 13:42:00', 67, 77, 77),
(264, '2023-04-22 18:03:00', 64, 94, 94),
(265, '2023-12-04 09:25:00', 93, 30, 30),
(266, '2024-06-19 20:31:00', 83, 2, 2),
(267, '2023-11-30 16:08:00', 60, 122, 122),
(268, '2023-12-26 15:40:00', 25, 36, 36),
(269, '2024-07-29 12:22:00', 26, 50, 165),
(270, '2023-09-11 18:45:00', 25, 98, 214),
(271, '2024-05-21 12:38:00', 51, 20, 20),
(272, '2024-07-22 13:03:00', 92, 96, 211),
(273, '2024-06-17 20:59:00', 91, 18, 18),
(274, '2023-11-05 10:44:00', 82, 122, 237),
(275, '2023-02-17 11:28:00', 64, 118, 233),
(276, '2024-11-22 14:53:00', 16, 77, 192),
(277, '2023-12-21 19:31:00', 86, 6, 6),
(278, '2024-05-24 18:23:00', 94, 11, 126),
(279, '2024-01-10 17:52:00', 88, 13, 128),
(280, '2024-06-21 18:03:00', 25, 15, 15),
(281, '2023-01-03 16:14:00', 60, 87, 87),
(282, '2024-07-27 09:11:00', 8, 94, 209),
(283, '2022-12-27 13:29:00', 10, 67, 67),
(284, '2024-06-01 11:42:00', 50, 51, 51),
(285, '2024-02-22 18:46:00', 30, 21, 136),
(286, '2023-04-06 14:07:00', 10, 71, 186),
(287, '2024-01-22 09:59:00', 81, 107, 222),
(288, '2023-03-25 12:24:00', 65, 40, 155),
(289, '2024-09-30 17:19:00', 38, 53, 168),
(290, '2024-10-27 12:05:00', 39, 67, 67),
(291, '2023-04-22 09:52:00', 21, 94, 94),
(292, '2023-06-01 10:13:00', 55, 107, 107),
(293, '2024-09-28 16:34:00', 45, 56, 171),
(294, '2024-04-14 14:24:00', 91, 118, 233),
(295, '2024-11-08 12:57:00', 61, 120, 235),
(296, '2024-07-05 20:14:00', 93, 55, 55),
(297, '2023-09-02 09:46:00', 96, 79, 79),
(298, '2023-05-17 19:36:00', 93, 17, 17),
(299, '2023-11-12 13:43:00', 71, 105, 245),
(300, '2023-06-27 09:18:00', 14, 114, 229),
(301, '2023-10-28 10:44:00', 10, 59, 174),
(302, '2023-08-03 18:22:00', 9, 28, 143),
(303, '2023-10-04 13:52:00', 83, 14, 14),
(304, '2024-04-09 20:21:00', 24, 33, 148),
(305, '2024-10-30 19:18:00', 77, 124, 124),
(306, '2023-06-11 17:25:00', 42, 25, 140),
(307, '2023-12-22 14:43:00', 33, 12, 12),
(308, '2023-07-18 18:09:00', 65, 45, 160),
(309, '2024-05-17 12:18:00', 40, 19, 19),
(310, '2024-10-23 15:49:00', 23, 118, 118),
(311, '2024-06-16 13:22:00', 90, 66, 66),
(312, '2023-08-08 12:54:00', 18, 49, 164),
(313, '2023-05-27 16:33:00', 58, 48, 163),
(314, '2023-12-11 19:11:00', 40, 85, 200),
(315, '2023-04-26 17:31:00', 67, 3, 3),
(316, '2023-07-30 18:27:00', 35, 33, 148),
(317, '2023-03-19 20:21:00', 59, 31, 146),
(318, '2023-09-13 16:56:00', 69, 70, 185),
(319, '2023-11-09 09:17:00', 75, 101, 216),
(320, '2023-08-01 10:58:00', 95, 87, 202),
(321, '2024-07-18 12:12:00', 92, 51, 166),
(322, '2023-04-26 10:09:00', 87, 1, 1),
(323, '2024-12-23 13:24:00', 57, 29, 144),
(324, '2024-04-04 12:31:00', 67, 75, 75),
(325, '2023-09-14 15:32:00', 49, 42, 157),
(326, '2023-07-16 09:19:00', 30, 114, 229),
(327, '2024-04-09 16:35:00', 63, 46, 161),
(328, '2024-02-18 18:19:00', 5, 7, 7),
(329, '2022-12-18 17:44:00', 99, 125, 240),
(330, '2023-05-11 15:03:00', 97, 28, 28),
(331, '2022-12-16 19:18:00', 72, 8, 8),
(332, '2024-04-01 11:29:00', 25, 29, 29),
(333, '2023-11-26 09:32:00', 7, 4, 4),
(334, '2023-03-22 15:11:00', 84, 60, 175),
(335, '2024-07-27 13:17:00', 31, 22, 22),
(336, '2023-02-07 16:23:00', 38, 105, 245),
(337, '2024-01-03 18:54:00', 57, 56, 56),
(338, '2023-02-22 12:38:00', 54, 78, 78),
(339, '2024-05-15 11:24:00', 91, 102, 102),
(340, '2024-07-09 20:14:00', 90, 28, 143),
(341, '2024-03-08 10:33:00', 79, 106, 221),
(342, '2023-05-10 19:11:00', 75, 24, 139),
(343, '2024-08-30 17:22:00', 2, 42, 157),
(344, '2022-12-21 14:52:00', 13, 62, 177),
(345, '2024-05-25 20:38:00', 34, 108, 108),
(346, '2024-07-30 11:27:00', 66, 71, 71),
(347, '2023-09-23 09:09:00', 72, 71, 71),
(348, '2024-02-03 17:43:00', 16, 19, 19),
(349, '2024-04-08 15:48:00', 26, 74, 74),
(350, '2023-05-15 19:51:00', 15, 90, 205),
(351, '2024-04-28 18:07:00', 87, 75, 75),
(352, '2025-01-17 12:05:00', 98, 84, 84),
(353, '2024-12-22 16:33:00', 61, 103, 218),
(354, '2023-08-08 14:47:00', 81, 98, 98),
(355, '2024-08-05 11:59:00', 35, 103, 103),
(356, '2024-07-01 19:34:00', 12, 108, 223),
(357, '2023-11-28 20:41:00', 7, 114, 114),
(358, '2023-10-15 14:06:00', 36, 56, 56),
(359, '2024-04-18 13:37:00', 47, 73, 188),
(360, '2023-02-19 18:33:00', 51, 23, 138),
(361, '2024-06-13 15:41:00', 31, 36, 151),
(362, '2023-12-08 18:28:00', 91, 78, 78),
(363, '2023-08-13 14:52:00', 18, 107, 107),
(364, '2024-01-01 10:49:00', 55, 50, 165),
(365, '2023-06-25 19:18:00', 80, 69, 69),
(366, '2023-08-21 20:22:00', 83, 45, 160),
(367, '2023-03-19 11:17:00', 47, 68, 183),
(368, '2024-01-01 17:32:00', 76, 55, 55),
(369, '2024-10-11 09:21:00', 7, 63, 63),
(370, '2023-10-21 11:22:00', 47, 99, 99),
(371, '2023-05-24 16:49:00', 37, 89, 89),
(372, '2024-01-03 10:41:00', 41, 29, 144),
(373, '2024-02-21 15:58:00', 40, 11, 11),
(374, '2023-09-28 14:24:00', 52, 95, 210),
(375, '2023-07-11 19:07:00', 89, 18, 18),
(376, '2024-01-21 14:12:00', 49, 11, 11),
(377, '2024-07-24 18:56:00', 69, 34, 149),
(378, '2023-03-15 12:38:00', 30, 69, 69),
(379, '2023-06-08 16:09:00', 89, 20, 135),
(380, '2024-11-10 17:47:00', 68, 62, 177),
(381, '2024-12-27 20:03:00', 86, 29, 29),
(382, '2024-11-27 13:54:00', 82, 49, 164),
(383, '2023-07-12 18:36:00', 43, 64, 179),
(384, '2023-02-11 16:26:00', 65, 68, 68),
(385, '2024-04-03 12:19:00', 83, 121, 236),
(386, '2024-01-04 14:03:00', 95, 78, 193),
(387, '2024-08-11 10:55:00', 78, 102, 102),
(388, '2024-09-15 16:18:00', 48, 21, 21),
(389, '2024-09-07 11:34:00', 51, 105, 220),
(390, '2024-09-08 13:27:00', 65, 39, 154),
(391, '2023-12-26 15:44:00', 53, 53, 168),
(392, '2023-11-29 20:13:00', 45, 95, 210),
(393, '2023-03-02 13:08:00', 5, 6, 6),
(394, '2024-05-17 19:21:00', 42, 5, 5),
(395, '2023-04-09 10:26:00', 82, 66, 181),
(396, '2024-03-16 19:19:00', 94, 13, 128),
(397, '2024-09-18 15:32:00', 72, 53, 168),
(398, '2024-02-11 11:47:00', 22, 51, 51),
(399, '2023-05-22 16:21:00', 42, 44, 44),
(400, '2024-05-09 13:54:00', 34, 12, 127),
(401, '2024-07-25 10:19:00', 75, 70, 185),
(402, '2024-11-09 18:43:00', 83, 76, 191),
(403, '2023-09-01 14:12:00', 47, 25, 140),
(404, '2024-06-11 12:51:00', 50, 32, 147),
(405, '2023-09-19 19:23:00', 28, 96, 96),
(406, '2023-06-10 09:47:00', 22, 39, 154),
(407, '2024-01-04 18:41:00', 68, 116, 116),
(408, '2024-01-22 15:34:00', 95, 50, 50),
(409, '2023-06-08 14:36:00', 27, 60, 60),
(410, '2023-09-07 12:58:00', 35, 56, 56),
(411, '2023-12-20 10:08:00', 92, 109, 109),
(412, '2023-01-10 09:21:00', 67, 78, 193),
(413, '2023-07-02 15:11:00', 55, 37, 37),
(414, '2024-06-03 13:02:00', 6, 106, 221),
(415, '2023-01-02 10:27:00', 27, 113, 113),
(416, '2023-08-18 12:31:00', 29, 89, 204),
(417, '2024-11-06 19:21:00', 53, 38, 153),
(418, '2024-07-22 11:36:00', 51, 122, 237),
(419, '2023-07-16 19:10:00', 99, 2, 2),
(420, '2024-07-28 16:57:00', 40, 24, 139),
(421, '2024-11-01 14:13:00', 32, 9, 9),
(422, '2024-09-28 11:29:00', 96, 26, 26),
(423, '2023-10-23 13:45:00', 12, 103, 218),
(424, '2024-07-25 14:17:00', 11, 67, 182),
(425, '2023-07-19 18:23:00', 36, 11, 126),
(426, '2024-07-04 19:37:00', 56, 28, 28),
(427, '2024-08-15 12:45:00', 47, 122, 222),
(428, '2024-11-06 18:09:00', 35, 52, 167),
(429, '2024-09-22 19:05:00', 72, 47, 162),
(430, '2024-03-11 09:29:00', 93, 38, 153),
(431, '2023-05-23 10:54:00', 32, 96, 211),
(432, '2024-08-01 14:16:00', 51, 103, 103),
(433, '2024-02-05 11:42:00', 88, 45, 160),
(434, '2023-02-13 13:05:00', 63, 53, 168),
(435, '2024-01-29 14:18:00', 5, 46, 46),
(436, '2024-09-08 15:09:00', 2, 17, 132),
(437, '2024-05-01 12:20:00', 3, 116, 231),
(438, '2023-03-09 19:52:00', 35, 87, 202),
(439, '2024-11-13 15:17:00', 37, 62, 177),
(440, '2024-12-23 11:32:00', 47, 118, 118),
(441, '2024-10-10 13:55:00', 5, 64, 179),
(442, '2024-07-21 20:40:00', 29, 18, 18),
(443, '2023-07-22 09:47:00', 35, 65, 65),
(444, '2024-11-11 18:01:00', 48, 118, 118),
(445, '2024-04-22 16:54:00', 76, 46, 46),
(446, '2023-07-12 13:42:00', 37, 114, 114),
(447, '2023-12-06 09:38:00', 97, 47, 162),
(448, '2023-11-07 15:09:00', 1, 45, 45),
(449, '2024-11-15 20:43:00', 31, 13, 13),
(450, '2023-10-14 10:14:00', 50, 108, 108),
(451, '2024-08-31 11:59:00', 97, 102, 242),
(452, '2023-03-15 13:25:00', 29, 77, 77),
(453, '2024-03-07 14:09:00', 84, 32, 147),
(454, '2024-03-03 19:18:00', 62, 120, 235),
(455, '2024-07-27 15:16:00', 25, 21, 136),
(456, '2024-06-23 14:27:00', 49, 6, 6),
(457, '2023-08-28 11:41:00', 25, 57, 57),
(458, '2023-03-07 19:33:00', 99, 20, 20),
(459, '2024-05-24 16:17:00', 60, 18, 133),
(460, '2024-12-16 09:57:00', 36, 61, 61),
(461, '2023-05-27 17:46:00', 13, 122, 237),
(462, '2023-07-10 12:34:00', 72, 24, 24),
(463, '2023-01-14 18:23:00', 14, 28, 28),
(464, '2023-10-05 16:11:00', 86, 34, 149),
(465, '2024-10-30 10:31:00', 85, 72, 187),
(466, '2023-08-02 15:23:00', 2, 39, 39),
(467, '2023-11-02 10:39:00', 16, 64, 64),
(468, '2024-12-11 19:15:00', 45, 25, 25),
(469, '2024-06-14 13:59:00', 18, 122, 237),
(470, '2024-10-20 15:08:00', 41, 80, 80),
(471, '2024-02-06 13:21:00', 57, 32, 32),
(472, '2023-08-03 09:18:00', 44, 37, 37),
(473, '2024-09-06 19:04:00', 16, 62, 62),
(474, '2024-05-09 14:16:00', 13, 106, 246),
(475, '2024-08-24 10:49:00', 25, 11, 11),
(476, '2023-08-09 17:23:00', 73, 55, 170),
(477, '2023-08-22 18:05:00', 17, 35, 35),
(478, '2023-01-31 11:42:00', 12, 98, 98),
(479, '2023-06-24 09:56:00', 71, 54, 169),
(480, '2023-02-08 12:14:00', 3, 3, 3),
(481, '2023-04-10 11:38:00', 82, 53, 168),
(482, '2023-08-22 15:47:00', 60, 38, 153),
(483, '2023-06-25 14:13:00', 43, 35, 150),
(484, '2023-07-13 13:22:00', 70, 26, 26),
(485, '2024-05-02 19:30:00', 74, 9, 9),
(486, '2024-05-23 17:49:00', 61, 76, 76),
(487, '2023-05-29 15:21:00', 10, 71, 186),
(488, '2024-08-08 18:36:00', 28, 3, 3),
(489, '2024-12-26 13:40:00', 49, 40, 40),
(490, '2024-06-07 12:17:00', 22, 17, 132),
(491, '2023-05-31 14:57:00', 22, 16, 16),
(492, '2024-08-25 10:29:00', 99, 40, 40),
(493, '2023-07-21 11:37:00', 14, 33, 148),
(494, '2023-09-20 19:28:00', 18, 109, 249),
(495, '2023-08-29 13:11:00', 47, 33, 148),
(496, '2024-12-22 18:47:00', 33, 14, 129),
(497, '2024-07-30 15:45:00', 90, 69, 69),
(498, '2024-03-03 12:26:00', 43, 16, 131),
(499, '2023-05-08 09:32:00', 44, 21, 21),
(500, '2023-11-15 17:21:00', 40, 28, 143);

INSERT INTO inventory (productid, regionid, stockquantity, lastupdate)
SELECT 
    p.productid,
    r.regionid,
    100 AS stockquantity,
    NOW() AS lastupdate
FROM 
    (SELECT productid FROM (SELECT 1 AS productid UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL
                            SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL
                            SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15 UNION ALL
                            SELECT 16 UNION ALL SELECT 17 UNION ALL SELECT 18 UNION ALL SELECT 19 UNION ALL SELECT 20 UNION ALL
                            SELECT 21 UNION ALL SELECT 22 UNION ALL SELECT 23 UNION ALL SELECT 24 UNION ALL SELECT 25 UNION ALL
                            SELECT 26 UNION ALL SELECT 27 UNION ALL SELECT 28 UNION ALL SELECT 29 UNION ALL SELECT 30 UNION ALL
                            SELECT 31 UNION ALL SELECT 32 UNION ALL SELECT 33 UNION ALL SELECT 34 UNION ALL SELECT 35 UNION ALL
                            SELECT 36 UNION ALL SELECT 37 UNION ALL SELECT 38 UNION ALL SELECT 39 UNION ALL SELECT 40 UNION ALL
                            SELECT 41 UNION ALL SELECT 42 UNION ALL SELECT 43 UNION ALL SELECT 44 UNION ALL SELECT 45 UNION ALL
                            SELECT 46 UNION ALL SELECT 47 UNION ALL SELECT 48 UNION ALL SELECT 49 UNION ALL SELECT 50 UNION ALL
                            SELECT 51 UNION ALL SELECT 52 UNION ALL SELECT 53 UNION ALL SELECT 54 UNION ALL SELECT 55 UNION ALL
                            SELECT 56 UNION ALL SELECT 57 UNION ALL SELECT 58 UNION ALL SELECT 59 UNION ALL SELECT 60 UNION ALL
                            SELECT 61 UNION ALL SELECT 62 UNION ALL SELECT 63 UNION ALL SELECT 64 UNION ALL SELECT 65 UNION ALL
                            SELECT 66 UNION ALL SELECT 67 UNION ALL SELECT 68 UNION ALL SELECT 69 UNION ALL SELECT 70 UNION ALL
                            SELECT 71 UNION ALL SELECT 72 UNION ALL SELECT 73 UNION ALL SELECT 74 UNION ALL SELECT 75 UNION ALL
                            SELECT 76 UNION ALL SELECT 77 UNION ALL SELECT 78 UNION ALL SELECT 79 UNION ALL SELECT 80 UNION ALL
                            SELECT 81 UNION ALL SELECT 82 UNION ALL SELECT 83 UNION ALL SELECT 84 UNION ALL SELECT 85 UNION ALL
                            SELECT 86 UNION ALL SELECT 87 UNION ALL SELECT 88 UNION ALL SELECT 89 UNION ALL SELECT 90 UNION ALL
                            SELECT 91 UNION ALL SELECT 92 UNION ALL SELECT 93 UNION ALL SELECT 94 UNION ALL SELECT 95 UNION ALL
                            SELECT 96 UNION ALL SELECT 97 UNION ALL SELECT 98 UNION ALL SELECT 99 UNION ALL SELECT 100) p) p
CROSS JOIN 
    (SELECT 1 AS regionid UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5) r;
 
 
 
 
 -- Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:



/* 1) Verificare che i campi definiti come PK siano univoci. In altre parole, 
scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).*/
 
    SELECT categoryID, count(*)
    from category
    group by categoryid
    having count(*) >1;
    
    SELECT customerid, count(*)
    from customer
    group by customerid
    having count(*) >1;
    
     SELECT inventoryid, count(*)
    from inventory
    group by inventoryid
    having count(*) >1;
    
    select productid, count(*)
    from product
    group by productid
    having count(*) >1;
    
select regionid, count(*)
    from region
    group by regionid
    having count(*) >1;
    
select saleid, count(*)
    from sales
    group by saleid
    having count(*) >1;

select salespointid, count(*)
    from sales_point
    group by SalesPointID
    having count(*) >1;

 select stateid, count(*)
    from state
    group by StateID
    having count(*) >1;
    
    
/*  2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
       la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
       in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */  
    
    
    select
    s.SaleID AS CodiceDocumento, 
    s.SaleDate AS Data,
    p.ProductName AS NomeProdotto, 
    p.CategoryID AS CategoriaProdotto, 
    st.StateName AS NomeStato, 
    r.RegionName AS NomeRegione, 
    CASE WHEN DATEDIFF(CURDATE(), s.SaleDate) > 180 THEN TRUE 
    ELSE FALSE END AS PiùDi180Giorni
    FROM sales s 
	JOIN product p ON s.ProductID = p.ProductID 
    JOIN sales_point sp ON s.SalesPointID = sp.SalesPointID 
    JOIN state st ON sp.StateID = st.StateID 
    JOIN region r ON st.RegionID = r.RegionID;
    
    /*3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, 
            una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
            (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
            Nel result set devono comparire solo il codice prodotto e il totale venduto.*/
            
WITH LastYear AS (
    SELECT MAX(YEAR(SaleDate)) AS LastCensusYear
    FROM Sales
),
    
  SalesByProduct AS (
    
    SELECT 
        s.ProductID,
        COUNT(s.SaleID) AS TotalSold
    FROM Sales s
    INNER JOIN LastYear ly ON YEAR(s.SaleDate) = ly.LastCensusYear
    GROUP BY s.ProductID
), 
    
    AverageSales AS (
    
    SELECT 
        AVG(TotalSold) AS AvgSales
    FROM SalesByProduct
)

SELECT 
    sbp.ProductID,
    sbp.TotalSold
FROM SalesByProduct sbp
CROSS JOIN AverageSales avg
WHERE sbp.TotalSold > avg.AvgSales;


/* 4)	Esporre l’elenco dei soli prodotti venduti 
e per ognuno di questi il fatturato totale per anno.*/


SELECT 
    p.ProductID,
    YEAR(s.SaleDate) AS SaleYear,
    SUM(p.ListPrice) AS TotalRevenue
FROM Product p
INNER JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, YEAR(s.SaleDate)
ORDER BY SaleYear, p.ProductID;


/* 5)	Esporre il fatturato totale per stato per anno. 
Ordina il risultato per data e per fatturato decrescente.*/

SELECT 
    st.StateName,
    YEAR(s.SaleDate) AS SaleYear,
    SUM(p.ListPrice) AS TotalRevenue
FROM Sales s
INNER JOIN Sales_Point sp ON s.SalesPointID = sp.SalesPointID
INNER JOIN State st ON sp.StateID = st.StateID
INNER JOIN Product p ON s.ProductID = p.ProductID
GROUP BY st.StateName, YEAR(s.SaleDate)
ORDER BY SaleYear ASC, TotalRevenue DESC;

/* 6)	Rispondere alla seguente domanda: qual è la categoria 
		di articoli maggiormente richiesta dal mercato? */

WITH CategorySales AS (
    SELECT 
        c.CategoryID,
        c.CategoryName,
        COUNT(s.SaleID) AS TotalSales
    FROM Sales s
    INNER JOIN Product p ON s.ProductID = p.ProductID
    INNER JOIN Category c ON p.CategoryID = c.CategoryID
    GROUP BY c.CategoryID, c.CategoryName
)
SELECT 
    CategoryID,
    CategoryName,
    TotalSales
FROM CategorySales
ORDER BY TotalSales DESC
LIMIT 1;

/*7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? 
    Proponi due approcci risolutivi differenti.
    
    Approccio NOT IN   */
    
SELECT 
    p.ProductID, 
    p.ProductName
FROM Product p
WHERE p.ProductID NOT IN (
    SELECT DISTINCT s.ProductID
    FROM Sales s
);

/* Approccio LEFT JOIN  */

SELECT 
    p.ProductID, 
    p.ProductName
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.ProductID IS NULL;

/* 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” 
		delle informazioni utili (codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW DenormalizedProductInfo AS
SELECT 
    p.ProductID,
    p.ProductName,
    c.CategoryName
FROM Product p
INNER JOIN Category c ON p.CategoryID = c.CategoryID;


-- 9)	Creare una vista per le informazioni geografiche

CREATE VIEW GeographicInfo AS
SELECT 
    sp.SalesPointID,
    sp.SalesPointName,
    sp.AddressLine,
    sp.City,
    st.StateName,
    r.RegionName
FROM Sales_Point sp
INNER JOIN State st ON sp.StateID = st.StateID
INNER JOIN Region r ON st.RegionID = r.RegionID;